/*
*********************************************************************************************************
*                                             uC/CSP
*                                        Chip Support Package
*
*                            (c) Copyright 2010; Micrium, Inc.; Weston, FL
*                         (c) Copyright 2003-2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved. Protected by international copyright laws.
*
*               uC/CSP is provided in source form to registered licensees ONLY.  It is
*               illegal to distribute this source code to any third party unless you receive
*               written permission by an authorized Micrium representative.  Knowledge of
*               the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*
*                                         INTERRUPT MANAGMENT
*                                 TEXAS INSTRUMENTS LM3Sxxxx FAMILY
* 
* Filename      : csp_int.c
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
* Note(s)       : (1) The following products are supported by this family definition.
*
*
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define    CSP_INT_MODULE
#include   <csp.h>


/*
*********************************************************************************************************
*                                          DEFAULT CONFIGURATION
*********************************************************************************************************
*/



/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/



/*
*********************************************************************************************************
*                                           LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                     INTERRUPT VECTOR TABLE
*
* Note(s) (1) 'CSP_MainVectTbl[]' store all the interrupts handlers for the external interrupts
*             on the MB9Bxxx series devices.
*********************************************************************************************************
*/

                                                                /* NVIC external interrupts vector table               */
static  CSP_INT_VECT  CSP_MainVectTbl[CSP_INT_SRC_NBR_MAX]; 

/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL MACRO's
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*********************************************************************************************************
*                                           LOCAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            CSP_IntClr()
*
* Description : Clear an interrupt source on a specific interrupt controller.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see note #1).
*
*               src_nbr    Interrupt source number. (see note #2). 
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) Interrupt controllers numbers identifiers can be found in 'csp_grp.h' 
* 
*                       CSP_INT_CTRL_NBR_XX'  where 'XX" is the name of the interrupt controller.
*
*               (2) Interrupt source identifiers can be found in 'csp_grp.h' as CSP_INT
*
*                       CSP_INT_SRC_NBR_XX      where XX is the peripheral or interrupt source name.
*                                               Main interrupt controller only.
* 
*                       CSP_INT_XX_SRC_NBR_YY   where xx is the name of the interrupt controller or shared 
*                                               handler and YY is the peripheral or source name.
*********************************************************************************************************
*/

void  CSP_IntClr (CSP_DEV_NBR  int_ctrl,
                  CSP_DEV_NBR  src_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl != CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  )) {
        return;
    }
#endif
    
    CPU_IntSrcPendClr(src_nbr + CPU_INT_EXT0);
}


/*
*********************************************************************************************************
*                                          CSP_IntDis()
*
* Description : Disable an interrupt source on a specific interrupt controller.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
*               src_nbr    Interrupt source number. (see 'CSP_IntClr()' note #2).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntDis (CSP_DEV_NBR  int_ctrl,
                  CSP_DEV_NBR  src_nbr)
{   
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl != CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  )) {
        return;
    }
#endif
    
    CPU_IntSrcDis(src_nbr + CPU_INT_EXT0);
}


/*
*********************************************************************************************************
*                                          CSP_IntDisAll()
*
* Description : Disable all interrupts on a specific interrupt controller.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntDisAll (CSP_DEV_NBR  int_ctrl)
{
    CSP_DEV_NBR  int_src;
    CSP_DEV_NBR  int_src_grp;
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if (int_ctrl != CSP_INT_CTRL_NBR_MAIN) {
        return;
    }
#endif
    
    int_src     = 0u;
    int_src_grp = 0u;
    while (int_src < CSP_INT_SRC_NBR_MAX) {
        CPU_REG_NVIC_CLREN(int_src_grp) = DEF_BIT_FIELD(32u, 0u);
        int_src_grp++;
        int_src += 32u;
    }    
}


/*
*********************************************************************************************************
*                                          CSP_IntEn()
*
* Description : Enable an interrupt source on a specific interrupt controller.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
*               src_nbr    Interrupt source number. (see 'CSP_IntClr()' note #2).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntEn (CSP_DEV_NBR  int_ctrl,
                 CSP_DEV_NBR  src_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl != CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  )) {
        return;
    }
#endif
    
    CPU_IntSrcEn(src_nbr + CPU_INT_EXT0);    
}


/*
*********************************************************************************************************
*                                          CSP_IntInit()
*
* Description : Initialize all interrupt controllers and shared handlers.
*                   (1) Disable all interrupts.
*                   (2) Clear all pending interrupts.
*                   (3) Initialize all vector interrupt tables.
*                   (4) Install all shared interrupt handlers. 
*
* Argument(s) : None.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntInit (void)
{
    CPU_INT08U     src_nbr;
    CSP_INT_VECT  *p_int_vect;
    CPU_SR_ALLOC();
    
    
    p_int_vect = &CSP_MainVectTbl[0];
    
    for (src_nbr = 0u; src_nbr < CSP_INT_SRC_NBR_MAX; src_nbr++) {
        CPU_IntSrcDis(src_nbr + CPU_INT_EXT0);                  /* Disable external interrupts.                       */
        CPU_IntSrcPendClr(src_nbr + CPU_INT_EXT0);
        p_int_vect = &CSP_MainVectTbl[src_nbr];
        
        CPU_CRITICAL_ENTER();
        CSP_IntVectClr(p_int_vect);                             /* Initialize main vector table entry.               */
        CPU_CRITICAL_EXIT();
    }
}


/*
*********************************************************************************************************
*                                          CSP_IntSrcCfg()
*
* Description : Configure an interrupt source.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
*               src_nbr    Interrupt source number. (see 'CSP_IntClr()' note #2).
*
*               src_prio   Interrupt source priority.
*
*               src_pol    Interrupt source polarity:
*                              CSP_INT_POL_LEVEL_HIGH           Interrupt is activated on a high level.
*                              CSP_INT_POL_LEVEL_LOW            Interrupt is activated on a low level.
* 
*                              CSP_INT_POL_EDGE_RISING          Interrupt is activated on the rising edge.
*                              CSP_INT_POL_EDGE_FALLING         Interrupt is activated on the falling edge.
*                              CSP_INT_POL_EDGE_BOTH            Interrupt is activated on both edges.       
*
*
* Return(s)   : DEF_OK,    if the interrupt source was configured
*               DEF_FAIL,  otherwise.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) Interrupt source priority is determined by the interrupt controller implementation.
*                   The maximum and minimum values are defined in the family definition file 'csp_grp.h'
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_IntSrcCfg (CSP_DEV_NBR  int_ctrl,
                            CSP_DEV_NBR  src_nbr,
                            CSP_OPT      src_prio,
                            CSP_OPT      src_pol)

{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl != CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  ) &&
        (src_prio >= 0xFFu                )) {
        return (DEF_FAIL);
    }
#endif
    
    CPU_IntSrcPrioSet(src_nbr + 16u, src_prio);
    
    return(DEF_OK);
}


/*
*********************************************************************************************************
*                                          CSP_IntVectReg()
*
* Description : Register an interrupt service routine handler for a specific interrupt controller.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
*               src_nbr    Interrupt source number. (see 'CSP_IntClr()' note #2).
*
*               isr_fnct    Pointer to the interrupt service routine (ISR).
*
*               p_arg       Pointer to the argument of the interrupt service routine (ISR).
*
* Return(s)   : DEF_OK,    If the vector was registered successfully.
*               DEF_FAIL,  otherwise.
*               
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_IntVectReg (CSP_DEV_NBR    int_ctrl,
                             CSP_DEV_NBR    src_nbr,
                             CPU_FNCT_PTR   isr_fnct,
                             void          *p_arg)
{
    CSP_INT_VECT  *p_int_vect;
    CPU_SR_ALLOC();
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl == CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  )) {
        return (DEF_FAIL);
    }
    
    if (isr_fnct == (CPU_FNCT_PTR)0u) {
        return (DEF_FAIL);
    }
#endif
    
    p_int_vect = (CSP_INT_VECT *)&CSP_MainVectTbl[src_nbr];
    
    CPU_CRITICAL_ENTER();
    
    CSP_IntVectSet((CSP_INT_VECT *)p_int_vect,
                   (CPU_FNCT_PTR  )isr_fnct,
                   (void         *)p_arg);
    
    CPU_CRITICAL_EXIT();    
    
    return (DEF_OK);
}


/*
*********************************************************************************************************
*                                          CSP_IntVectUnreg()
*
* Description : Un-register an interrupt vector.
*
* Argument(s) : int_ctrl   Interrupt controller number. (see 'CSP_IntClr()' note #1).
*
*               src_nbr    Interrupt source number. (see 'CSP_IntClr()' note #2).
*
* Return(s)   : DEF_OK,     If the vector was unregistered successfully.
*               DEF_FAIL,   otherwise.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_IntVectUnreg (CSP_DEV_NBR  int_ctrl,
                               CSP_DEV_NBR  src_nbr)
{
    CSP_INT_VECT  *p_int_vect;
    CPU_SR_ALLOC();
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((int_ctrl == CSP_INT_CTRL_NBR_MAIN) &&
        (src_nbr  >= CSP_INT_SRC_NBR_MAX  )) {
        return (DEF_FAIL);
    }    
#endif
    
    p_int_vect = (CSP_INT_VECT *)&CSP_MainVectTbl[src_nbr];
    
    CPU_CRITICAL_ENTER();
    
    CSP_IntVectClr(p_int_vect);
    
    CPU_CRITICAL_EXIT();
    
    return (DEF_OK);
}


/*
*********************************************************************************************************
*                                       CSP_IntHandlerSrc()
*
* Description : Global interrupt handler.
*
* Argument(s) : src_nbr      Interrupt source number.
*
* Return(s)   : none
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntHandlerSrc (CSP_DEV_NBR  src_nbr)
{
    CSP_INT_VECT  *p_int_vect;
    
    
    if (src_nbr < CSP_INT_SRC_NBR_MAX) {
        p_int_vect = &CSP_MainVectTbl[src_nbr];
        
        CSP_IntVectDeref(p_int_vect);                           /* Call Dereferencing funtion                          */
        
    }
}


/*
*********************************************************************************************************
*                                       CSP_IntHandlerSrc()
*
* Description : Global interrupt handler.
*
* Argument(s) : None.
*
* Return(s)   : none
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_IntHandler  (void)
{
    CSP_INT_VECT  *p_int_vect;
    CSP_DEV_NBR    src_nbr;
    CPU_INT32U     reg_val;
    
                                                                /* Query the NVIC interrupt controller                 */
    reg_val = (CPU_REG_NVIC_ICSR & CPU_MSK_NVIC_ICSR_VECT_ACTIVE);
    src_nbr = (CSP_DEV_NBR)reg_val - CPU_INT_EXT0;
    
    if (src_nbr < CSP_INT_SRC_NBR_MAX) {
        p_int_vect = &CSP_MainVectTbl[src_nbr];
        
        CSP_IntVectDeref(p_int_vect);                           /* Call Dereferencing funtion                          */
    }  
}
