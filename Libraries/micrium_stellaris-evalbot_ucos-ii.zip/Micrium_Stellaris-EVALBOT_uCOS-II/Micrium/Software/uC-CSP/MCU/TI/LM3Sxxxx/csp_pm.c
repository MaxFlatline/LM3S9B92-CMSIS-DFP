/*
*********************************************************************************************************
*                                             uC/CSP
*                                        Chip Support Package
*
*                            (c) Copyright 2010; Micrium, Inc.; Weston, FL
*                         (c) Copyright 2003-2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved. Protected by international copyright laws.
*
*               uC/CSP is provided in source form to registered licensees ONLY.  It is
*               illegal to distribute this source code to any third party unless you receive
*               written permission by an authorized Micrium representative.  Knowledge of
*               the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*
*                                      POWER & CLOCK MANAGEMENT
*                                 TEXAS INSTRUMENTS LM3Sxxxx FAMILY
*
* Filename      : csp_pm.c
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
* Note(s)       : (1) The following products are supported by this family definition.
*
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define    CSP_PM_MODULE
#include   <csp.h>


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/

#define  CSP_PM_REG_SYS_CTRL_BASE_ADDR               (CPU_INT32U)(0x400FE000u)

#define  CSP_PM_REG_SYS_CTRL_RCC                  (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x060u))
#define  CSP_PM_REG_SYS_CTRL_PLLCFG               (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x064u))
#define  CSP_PM_REG_SYS_CTRL_RCC2                 (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x070u))
#define  CSP_PM_REG_SYS_CTRL_MOSCCTL              (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x07Cu))
#define  CSP_PM_REG_SYS_CTRL_RCGC0                (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x100u))
#define  CSP_PM_REG_SYS_CTRL_RCGC1                (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x104u))
#define  CSP_PM_REG_SYS_CTRL_RCGC2                (*(CPU_REG32 *)(CSP_PM_REG_SYS_CTRL_BASE_ADDR + 0x108u))

#define  CSP_PM_VAL_PIOSC_FREQ_HZ                       16000000u
#define  CSP_PM_VAL_I30k_OSC_FREQ_HZ                       30000u

#define  CSP_PM_BIT_RCC_MOSCDIS                        DEF_BIT_00
#define  CSP_PM_BIT_RCC_IOSCDIS                        DEF_BIT_01
#define  CSP_PM_BIT_RCC_OSCSRC_MOSC                    DEF_BIT_MASK(0u, 4u)
#define  CSP_PM_BIT_RCC_OSCSRC_PIOSC                   DEF_BIT_MASK(1u, 4u)
#define  CSP_PM_BIT_RCC_OSCSRC_PIOSC_DIV4              DEF_BIT_MASK(2u, 4u)
#define  CSP_PM_BIT_RCC_OSCSRC_30k_HZ                  DEF_BIT_MASK(3u, 4u)
#define  CSP_PM_BIT_RCC_XTAL_MASK                      DEF_BIT_FIELD(5u, 0u)
#define  CSP_PM_BIT_RCC_BYPASS                         DEF_BIT_11
#define  CSP_PM_BIT_RCC_PWMDN                          DEF_BIT_13
#define  CSP_PM_BIT_RCC_USESYSDIV                      DEF_BIT_22
#define  CSP_PM_BIT_RCC_SYSDIV                         DEF_BIT_FIELD(4u, 23u)

#define  CSP_PM_BIT_RCC2_OSCSRC_MOSC                   DEF_BIT_MASK(0u, 4u)
#define  CSP_PM_BIT_RCC2_OSCSRC_PIOSC                  DEF_BIT_MASK(1u, 4u)
#define  CSP_PM_BIT_RCC2_OSCSRC_PIOSC_DIV4             DEF_BIT_MASK(2u, 4u)
#define  CSP_PM_BIT_RCC2_OSCSRC_30k_HZ                 DEF_BIT_MASK(3u, 4u)
#define  CSP_PM_BIT_RCC2_BYPASS2                       DEF_BIT_11
#define  CSP_PM_BIT_RCC2_PWRDN2                        DEF_BIT_13
#define  CSP_PM_BIT_RCC2_USBPWRDN                      DEF_BIT_14
#define  CSP_PM_BIT_RCC2_SYSDIV2LSB                    DEF_BIT_22
#define  CSP_PM_BIT_RCC2_SYSDIV2                       DEF_BIT_FIELD(6u, 23u)
#define  CSP_PM_BIT_RCC2_DIV400                        DEF_BIT_30
#define  CSP_PM_BIT_RCC2_USERCC2                       DEF_BIT_31

#define  CSP_PM_BIT_PLLCFG_F_MASK                      DEF_BIT_FIELD(9u, 0u)
#define  CSP_PM_BIT_PLLCFG_R_MASK                      DEF_BIT_FIELD(5u, 0u)

#define  CSP_PM_CLK_SRC_MOSCS                              0u
#define  CSP_PM_CLK_SRC_PIOSC                              1u
#define  CSP_PM_CLK_SRC_PIOSC_DIV4                         2u
#define  CSP_PM_CLK_SRC_30k_HZ                             3u


/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/

static  const  CPU_INT32U  main_xtal_freq [] = 
{
    1000000,
    1843200,
    2000000,
    2457600,
    3579545,
    3686400,
    4000000,
    4096000,
    4915200,
    5000000,
    5120000,
    6000000,
    6144000,
    7372800,
    8000000,
    8192000,
    10000000,
    12000000,
    12288000,
    13560000,
    14318180,
    16000000,
    16384000
};

/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            LOCAL MACRO's
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*********************************************************************************************************
*                                           LOCAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            CSP_PM_Init()
*
* Description : Initialize power management module.
*
* Argument(s) : none.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_PM_Init (void) 
{

}   

/*
*********************************************************************************************************
*                                       CSP_PM_CPU_ClkFreqGet()
*
* Description : Return CPU clock frequency.
*                   
* Argument(s) : None.
*  
* Return(s)   : The CPU frequency in Hertz.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CPU_INT32U  CSP_PM_CPU_ClkFreqGet (void)
{   
    CPU_INT32U  cpu_freq;    

    cpu_freq = CSP_PM_SysClkFreqGet(CSP_PM_SYS_CLK_NBR_SYS_00);
    
    return (cpu_freq);
}


/*
*********************************************************************************************************
*                                          CSP_PM_PerClkEn()
*
* Description : Enable a peripheral clock.
*                   
* Argument(s) : clk_nbr     Peripheral clock number. (see 'CSP_PM_PerClkCfg()' note #1).
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  CSP_PM_PerClkEn (CSP_DEV_NBR clk_nbr)
{
    CPU_INT32U  reg_bit;
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if (clk_nbr > (CSP_PM_PER_CLK_NBR_MAX - 1u)) {
        return;
    }
#endif
       
    switch (clk_nbr) {
        case CSP_PM_PER_CLK_NBR_WDT_00:
        case CSP_PM_PER_CLK_NBR_ADC_00:
        case CSP_PM_PER_CLK_NBR_ADC_01:
        case CSP_PM_PER_CLK_NBR_PWM_00:
        case CSP_PM_PER_CLK_NBR_CAN_00:
        case CSP_PM_PER_CLK_NBR_CAN_01:
        case CSP_PM_PER_CLK_NBR_WDT_01:
             reg_bit = DEF_BIT(clk_nbr - CSP_PM_PER_CLK_RCGC0_OFFSET);
             DEF_BIT_SET(CSP_PM_REG_SYS_CTRL_RCGC0, reg_bit);
             break;
             
        case CSP_PM_PER_CLK_NBR_UART_00:
        case CSP_PM_PER_CLK_NBR_UART_01:
        case CSP_PM_PER_CLK_NBR_UART_02:
        case CSP_PM_PER_CLK_NBR_SSI_00:
        case CSP_PM_PER_CLK_NBR_SSI_01:
        case CSP_PM_PER_CLK_NBR_QEI_00:
        case CSP_PM_PER_CLK_NBR_QEI_01:
        case CSP_PM_PER_CLK_NBR_I2C_00:
        case CSP_PM_PER_CLK_NBR_I2C_01:
        case CSP_PM_PER_CLK_NBR_TMR_00:
        case CSP_PM_PER_CLK_NBR_TMR_01:
        case CSP_PM_PER_CLK_NBR_TMR_02:
        case CSP_PM_PER_CLK_NBR_TMR_03:
        case CSP_PM_PER_CLK_NBR_COMP_00:
        case CSP_PM_PER_CLK_NBR_COMP_01:
        case CSP_PM_PER_CLK_NBR_COMP_02:
        case CSP_PM_PER_CLK_NBR_I2S_00:
        case CSP_PM_PER_CLK_NBR_EPI_00:
             reg_bit = DEF_BIT(clk_nbr);
             DEF_BIT_SET(CSP_PM_REG_SYS_CTRL_RCGC1, reg_bit);        
             break;
             
        case CSP_PM_PER_CLK_NBR_GPIO_A:
        case CSP_PM_PER_CLK_NBR_GPIO_B:
        case CSP_PM_PER_CLK_NBR_GPIO_C:
        case CSP_PM_PER_CLK_NBR_GPIO_D:
        case CSP_PM_PER_CLK_NBR_GPIO_E:
        case CSP_PM_PER_CLK_NBR_GPIO_F:
        case CSP_PM_PER_CLK_NBR_GPIO_G:
        case CSP_PM_PER_CLK_NBR_GPIO_H:
        case CSP_PM_PER_CLK_NBR_GPIO_J:
        case CSP_PM_PER_CLK_NBR_UDMA_00:
        case CSP_PM_PER_CLK_NBR_USB_00:
        case CSP_PM_PER_CLK_NBR_EMAC_00:
        case CSP_PM_PER_CLK_NBR_EPHY_00:
             reg_bit = DEF_BIT(clk_nbr - CSP_PM_PER_CLK_RCGC2_OFFSET);
             DEF_BIT_SET(CSP_PM_REG_SYS_CTRL_RCGC2, reg_bit);        
             break;
             
        default:
             break;
    }
    
}


/*
*********************************************************************************************************
*                                         CSP_PM_PerClkDis()
*
* Description : Disable a peripheral clock.
*                   
* Argument(s) : clk_nbr     Peripheral clock number. (see 'CSP_PM_PerClkCfg()' note #1).
*
* Return(s)   : none
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  CSP_PM_PerClkDis (CSP_DEV_NBR  clk_nbr)
{
    CPU_INT32U  reg_bit;
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if (clk_nbr > (CSP_PM_PER_CLK_NBR_MAX - 1u)) {
        return;
    }
#endif
       
    switch (clk_nbr) {
        case CSP_PM_PER_CLK_NBR_WDT_00:
        case CSP_PM_PER_CLK_NBR_ADC_00:
        case CSP_PM_PER_CLK_NBR_ADC_01:
        case CSP_PM_PER_CLK_NBR_PWM_00:
        case CSP_PM_PER_CLK_NBR_CAN_00:
        case CSP_PM_PER_CLK_NBR_CAN_01:
        case CSP_PM_PER_CLK_NBR_WDT_01:
             reg_bit = DEF_BIT(clk_nbr - CSP_PM_PER_CLK_RCGC0_OFFSET);
             DEF_BIT_CLR(CSP_PM_REG_SYS_CTRL_RCGC0, reg_bit);
             break;
             
        case CSP_PM_PER_CLK_NBR_UART_00:
        case CSP_PM_PER_CLK_NBR_UART_01:
        case CSP_PM_PER_CLK_NBR_UART_02:
        case CSP_PM_PER_CLK_NBR_SSI_00:
        case CSP_PM_PER_CLK_NBR_SSI_01:
        case CSP_PM_PER_CLK_NBR_QEI_00:
        case CSP_PM_PER_CLK_NBR_QEI_01:
        case CSP_PM_PER_CLK_NBR_I2C_00:
        case CSP_PM_PER_CLK_NBR_I2C_01:
        case CSP_PM_PER_CLK_NBR_TMR_00:
        case CSP_PM_PER_CLK_NBR_TMR_01:
        case CSP_PM_PER_CLK_NBR_TMR_02:
        case CSP_PM_PER_CLK_NBR_TMR_03:
        case CSP_PM_PER_CLK_NBR_COMP_00:
        case CSP_PM_PER_CLK_NBR_COMP_01:
        case CSP_PM_PER_CLK_NBR_COMP_02:
        case CSP_PM_PER_CLK_NBR_I2S_00:
        case CSP_PM_PER_CLK_NBR_EPI_00:
             reg_bit = DEF_BIT(clk_nbr);
             DEF_BIT_CLR(CSP_PM_REG_SYS_CTRL_RCGC1, reg_bit);        
             break;
             
        case CSP_PM_PER_CLK_NBR_GPIO_A:
        case CSP_PM_PER_CLK_NBR_GPIO_B:
        case CSP_PM_PER_CLK_NBR_GPIO_C:
        case CSP_PM_PER_CLK_NBR_GPIO_D:
        case CSP_PM_PER_CLK_NBR_GPIO_E:
        case CSP_PM_PER_CLK_NBR_GPIO_F:
        case CSP_PM_PER_CLK_NBR_GPIO_G:
        case CSP_PM_PER_CLK_NBR_GPIO_H:
        case CSP_PM_PER_CLK_NBR_GPIO_J:
        case CSP_PM_PER_CLK_NBR_UDMA_00:
        case CSP_PM_PER_CLK_NBR_USB_00:
        case CSP_PM_PER_CLK_NBR_EMAC_00:
        case CSP_PM_PER_CLK_NBR_EPHY_00:
             reg_bit = DEF_BIT(clk_nbr - CSP_PM_PER_CLK_RCGC2_OFFSET);
             DEF_BIT_CLR(CSP_PM_REG_SYS_CTRL_RCGC2, reg_bit);        
             break;
             
        default:
             break;
    }
}


/*
*********************************************************************************************************
*                                        CSP_PM_PerClkFreqGet()
*
* Description : Return the Peripheral clock
*
* Argument(s) : clk_nbr     Peripheral clock number. (see 'CSP_PM_PerClkCfg()' note #1).
*
* Return(s)   : The peripheral clock frequency.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

CPU_INT32U  CSP_PM_PerClkFreqGet (CSP_DEV_NBR  clk_nbr)
{
    CPU_INT32U  cpu_freq;
      
    
    cpu_freq = 0u;
    
    return (cpu_freq);
}


/*
*********************************************************************************************************
*                                          CSP_PM_SysClkEn()
*
* Description : Enable a System Clock.
*
* Argument(s) : clk_nbr     System clock number (see note #1)
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) System clks number are defined in 'csp_grp.h'.
*
*                       CSP_SYS_CLK_NBR_XX  where 'XX' is the system clock name.
*********************************************************************************************************
*/

void  CSP_PM_SysClkEn (CSP_DEV_NBR  clk_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if (clk_nbr > (CSP_PM_SYS_CLK_NBR_MAX - 1u)) {
        return;
    }
#endif 
    
}


/*
*********************************************************************************************************
*                                         CSP_PM_SysClkDis()
*
* Description : Disable a System Clock
*                   
* Argument(s) : clk_nbr     System clock number (see 'CSP_PM_SysClkEn()'note #1)
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  CSP_PM_SysClkDis (CSP_DEV_NBR clk_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if (clk_nbr > (CSP_PM_SYS_CLK_NBR_MAX - 1u)) {
        return;
    }
#endif 
    
}


/*
*********************************************************************************************************
*                                       CSP_PM_SysClkFreqGet()
*
* Description : Return the frequency for a specific system clock.
*                   
* Argument(s) : clk_nbr     System clock number (see 'CSP_PM_SysClkEn()'note #1)
*
* Return(s)   : The system clock frequency.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

CPU_INT32U  CSP_PM_SysClkFreqGet (CSP_DEV_NBR  clk_nbr)
{
    CPU_INT32U  sys_clk_freq;
    CPU_INT32U  bclk_freq;
    CPU_INT32U  pll_freq;
    CPU_INT32U  pll_freq_div2;
    CPU_INT08U  xtal_val;
    CPU_INT08U  clk_src;
    CPU_REG32   reg_rcc;
    CPU_REG32   reg_rcc2;
    CPU_INT32U  pll_f;
    CPU_INT32U  pll_r;    
    
    
    sys_clk_freq = 0u;
    bclk_freq    = 0u;
    pll_freq     = 0u;
    reg_rcc      = CSP_PM_REG_SYS_CTRL_RCC;
    reg_rcc2     = CSP_PM_REG_SYS_CTRL_RCC2;
    
    if (DEF_BIT_IS_SET(reg_rcc2, CSP_PM_BIT_RCC2_USERCC2)) {
        clk_src = (reg_rcc2 >> 4) & DEF_BIT_FIELD(3u, 0u);
    } else {
        clk_src = (reg_rcc >> 4) & DEF_BIT_FIELD(2u, 0u);
    }
    
    switch (clk_src) {
        case CSP_PM_CLK_SRC_MOSCS:
             xtal_val = (reg_rcc >> 6u) & CSP_PM_BIT_RCC_XTAL_MASK;
             bclk_freq = main_xtal_freq[xtal_val] / DEF_TIME_NBR_uS_PER_SEC;
             break;
             
        case CSP_PM_CLK_SRC_PIOSC:
             bclk_freq = CSP_PM_VAL_PIOSC_FREQ_HZ / DEF_TIME_NBR_uS_PER_SEC;
             break;
             
        case CSP_PM_CLK_SRC_PIOSC_DIV4:
             bclk_freq = (CSP_PM_VAL_PIOSC_FREQ_HZ / 4u) / DEF_TIME_NBR_uS_PER_SEC;
             break;
             
        case CSP_PM_CLK_SRC_30k_HZ:
             bclk_freq = CSP_PM_VAL_I30k_OSC_FREQ_HZ / DEF_TIME_NBR_mS_PER_SEC;
             break;
             
        default:
             break;
    } 
    
    sys_clk_freq = bclk_freq;
    
    if ((DEF_BIT_IS_SET(reg_rcc2, CSP_PM_BIT_RCC2_USERCC2) && DEF_BIT_IS_CLR(reg_rcc2, CSP_PM_BIT_RCC2_BYPASS2)) ||
        (DEF_BIT_IS_CLR(reg_rcc2, CSP_PM_BIT_RCC2_USERCC2) && DEF_BIT_IS_CLR(reg_rcc, CSP_PM_BIT_RCC_BYPASS))) {
        pll_f = (CSP_PM_REG_SYS_CTRL_PLLCFG >> 5u) & CSP_PM_BIT_PLLCFG_F_MASK;
        pll_r = CSP_PM_REG_SYS_CTRL_PLLCFG & CSP_PM_BIT_PLLCFG_R_MASK;
                 
        pll_freq      = (bclk_freq * pll_f) / (pll_r + 1u);
        pll_freq_div2 = pll_freq / 2u; 
                 
        if (DEF_BIT_IS_SET(reg_rcc2, CSP_PM_BIT_RCC2_DIV400)) {
            pll_freq /= ((reg_rcc2 >> 22u) & DEF_BIT_FIELD(7u, 0u)) + 1u;
        } else {
            pll_freq  = pll_freq_div2 / (((reg_rcc2 >> 23u) & DEF_BIT_FIELD(7u, 0u)) + 1u);
        }
        
        sys_clk_freq = pll_freq;
    }
    
    switch (clk_nbr) {
        case CSP_PM_SYS_CLK_NBR_SYS_00:
             sys_clk_freq *= DEF_TIME_NBR_uS_PER_SEC;
             break;        
             
        case CSP_PM_SYS_CLK_NBR_USB_00:
        case CSP_PM_SYS_CLK_NBR_ADC_00:
        case CSP_PM_SYS_CLK_NBR_PMW_00:
        case CSP_PM_SYS_CLK_NBR_I2S_RX_00:
        case CSP_PM_SYS_CLK_NBR_I2S_TX_00:        
        default:
             break;
        
    }  
    
    return (sys_clk_freq);
}

/*
*********************************************************************************************************
*                                         CSP_PM_SysClkDivCfg()
*
* Description : Configure peripheral clock divider.
*                   
* Argument(s) : clk_nbr     System clock number (see 'CSP_PM_SysClkEn()'note #1)
*  
*               clk_div     System clock divider.
*
* Return(s)   : DEF_OK,    If the clock was configured,
*               DEF_FAIL,  otherwise.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) Peripheral clk number are defined in 'csp_grp.h'.
*
*                       CSP_PER_CLK_NBR_XX  where 'XX' is the peripheral clock name.
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_PM_SysClkDivCfg (CSP_DEV_NBR  clk_nbr,
                                  CPU_SIZE_T   clk_div)
{
    (void)&clk_nbr;
    (void)&clk_div;
    
    return (DEF_OK);
}


