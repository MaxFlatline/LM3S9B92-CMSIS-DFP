/*
*********************************************************************************************************
*                                             uC/CSP
*                                        Chip Support Package
*
*                            (c) Copyright 2010; Micrium, Inc.; Weston, FL
*                         (c) Copyright 2003-2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved. Protected by international copyright laws.
*
*               uC/CSP is provided in source form to registered licensees ONLY.  It is
*               illegal to distribute this source code to any third party unless you receive
*               written permission by an authorized Micrium representative.  Knowledge of
*               the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*
*                                   GENERAL PURPOSE I/O CONTROLLER
*                                 TEXAS INSTRUMENTS LM3Sxxxx FAMILY
*
* Filename      : csp_gio.c
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
* Note(s)       : (1) The following products are supported by this family definition.
*
*
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define    CSP_GPIO_MODULE
#include   <csp.h>

/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/
                                                                /* ------- GENERAL-PURPOSE I/O BASE ADDRESSES --------- */
#define  CSP_GPIO_REG_APB_PORT_A_BASE_ADDR                 ((CPU_INT32U)(0x40004000u))
#define  CSP_GPIO_REG_APB_PORT_B_BASE_ADDR                 ((CPU_INT32U)(0x40005000u))
#define  CSP_GPIO_REG_APB_PORT_C_BASE_ADDR                 ((CPU_INT32U)(0x40006000u))
#define  CSP_GPIO_REG_APB_PORT_D_BASE_ADDR                 ((CPU_INT32U)(0x40007000u))
#define  CSP_GPIO_REG_APB_PORT_E_BASE_ADDR                 ((CPU_INT32U)(0x40024000u))
#define  CSP_GPIO_REG_APB_PORT_F_BASE_ADDR                 ((CPU_INT32U)(0x40025000u))
#define  CSP_GPIO_REG_APB_PORT_G_BASE_ADDR                 ((CPU_INT32U)(0x40026000u))
#define  CSP_GPIO_REG_APB_PORT_H_BASE_ADDR                 ((CPU_INT32U)(0x40027000u))
#define  CSP_GPIO_REG_APB_PORT_J_BASE_ADDR                 ((CPU_INT32U)(0x4003D000u))

#define  CSP_GPIO_REG_AHB_PORT_A_BASE_ADDR                 ((CPU_INT32U)(0x40058000u))
#define  CSP_GPIO_REG_AHB_PORT_B_BASE_ADDR                 ((CPU_INT32U)(0x40059000u))
#define  CSP_GPIO_REG_AHB_PORT_C_BASE_ADDR                 ((CPU_INT32U)(0x4005A000u))
#define  CSP_GPIO_REG_AHB_PORT_D_BASE_ADDR                 ((CPU_INT32U)(0x4005B000u))
#define  CSP_GPIO_REG_AHB_PORT_E_BASE_ADDR                 ((CPU_INT32U)(0x4005C000u))
#define  CSP_GPIO_REG_AHB_PORT_F_BASE_ADDR                 ((CPU_INT32U)(0x4005D000u))
#define  CSP_GPIO_REG_AHB_PORT_G_BASE_ADDR                 ((CPU_INT32U)(0x4005E000u))
#define  CSP_GPIO_REG_AHB_PORT_H_BASE_ADDR                 ((CPU_INT32U)(0x4005F000u))
#define  CSP_GPIO_REG_AHB_PORT_J_BASE_ADDR                 ((CPU_INT32U)(0x40060000u))

                                                                /* ------ GENERAL-PURPOSE I/O (GPIOs) REGISTERS ------- */
#define  CSP_GPIO_REG_DATA(port_addr, pins)       (*(CPU_REG32 *)(port_addr + 0x000u +(0x00000000u + (pins << 2u))))
#define  CSP_GPIO_REG_DIR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x400u))
#define  CSP_GPIO_REG_IS(port_addr)               (*(CPU_REG32 *)(port_addr + 0x404u))
#define  CSP_GPIO_REG_IBE(port_addr)              (*(CPU_REG32 *)(port_addr + 0x408u))
#define  CSP_GPIO_REG_IEV(port_addr)              (*(CPU_REG32 *)(port_addr + 0x40Cu))
#define  CSP_GPIO_REG_IM(port_addr)               (*(CPU_REG32 *)(port_addr + 0x410u))
#define  CSP_GPIO_REG_RIS(port_addr)              (*(CPU_REG32 *)(port_addr + 0x414u))
#define  CSP_GPIO_REG_MIS(port_addr)              (*(CPU_REG32 *)(port_addr + 0x418u))
#define  CSP_GPIO_REG_ICR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x41Cu))
#define  CSP_GPIO_REG_AFSEL(port_addr)            (*(CPU_REG32 *)(port_addr + 0x420u))
#define  CSP_GPIO_REG_DR2R(port_addr)             (*(CPU_REG32 *)(port_addr + 0x500u))
#define  CSP_GPIO_REG_DR4R(port_addr)             (*(CPU_REG32 *)(port_addr + 0x504u))
#define  CSP_GPIO_REG_DR8R(port_addr)             (*(CPU_REG32 *)(port_addr + 0x508u))
#define  CSP_GPIO_REG_ODR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x50Cu))
#define  CSP_GPIO_REG_PUR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x510u))
#define  CSP_GPIO_REG_PDR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x514u))
#define  CSP_GPIO_REG_SLR(port_addr)              (*(CPU_REG32 *)(port_addr + 0x518u))
#define  CSP_GPIO_REG_ODEN(port_addr)             (*(CPU_REG32 *)(port_addr + 0x51Cu))
#define  CSP_GPIO_REG_LOCK(port_addr)             (*(CPU_REG32 *)(port_addr + 0x520u))
#define  CSP_GPIO_REG_CR(port_addr)               (*(CPU_REG32 *)(port_addr + 0x524u))
#define  CSP_GPIO_REG_AMSEL(port_addr)            (*(CPU_REG32 *)(port_addr + 0x528u))
#define  CSP_GPIO_REG_PCTL(port_addr)             (*(CPU_REG32 *)(port_addr + 0x52Cu))

/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  CPU_INT32U  CSP_GPIO_GetPortAddr (CSP_DEV_NBR  port);

/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/



/*
*********************************************************************************************************
*********************************************************************************************************
*                                           LOCAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                          CSP_GPIO_Init()
*
* Description : Initialize general purpose I/O module.
*
* Argument(s) : none.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_GPIO_Init (void) 
{

} 

/*
*********************************************************************************************************
*                                          CSP_GPIO_Cfg()
*
* Description : Configure a set of pins for a specific I/O port
*
* Argument(s) : port_nbr    GPIO port number. (see note #1)
*
*               pins        Bit mask specifying which pins to configure.
*
*               dir         Pins direction :
*                               CSP_GPIO_DIR_IN                  Pins are configured as inputs.
*                               CSP_GPIO_DIR_OUT                 Pins are configured as outputs.
*                               CSP_GPIO_DIR_INOUT               Pins are configured as bidirectional pins.
*
*               drv_mode    Pins Drive mode flags (not used):
*                               CSP_GPIO_FLAG_MODE_NONE          Pins have neither pull-down nor pull-up.
*                               CSP_GPIO_FLAG_MODE_PULLUP        Pins have a pull-up   resistor enabled.
*                               CSP_GPIO_FLAG_MODE_PULLDOWN      Pins have a pull-down resistor enabled.
*                               CSP_GPIO_FLAG_MODE_SCH_TRIGGER   Pins have schmitt trigger.
*                               CSP_GPIO_FLAG_MODE_OPEN_DRAIN    Pins have open drain enabled.
*
*               int_en      Pin Interrupt enable:
*                               DEF_YES                          Pin interrupt is enabled.
*                               DEF_NO                           Pin Interrupt is disabled.
*
*               int_pol     Pin interrupt polarity:
*                               CSP_INT_POL_LEVEL_HIGH           Pin interrupt is activated on a high level.
*                               CSP_INT_POL_LEVEL_LOW            Pin interrupt is activated on a low level.
* 
*                               CSP_INT_POL_EDGE_POSITIVE        Pin interrupt is activated on the positive edge.
*                               CSP_INT_POL_EDGE_NEGATIVE        Pin interrupt is activated on the negative edge.
*                               CSP_INT_POL_EDGE_BOTH            Pin interrupt is activated on both edges.
*             
*               fnct        Pins function (see note #2).
*
* Return(s)   : DEF_OK    If the pins were configured successfully.
*               DEF_FAIL  If the pins could not be configured successfully.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) The 'port_nbr' argument depends on the number of GPIO ports available for this 
*                   family definition.
*
*                   (a) Port numbers identifiers can be found in 'csp.h':
*
*                           CSP_GPIO_PORT_NBR_00
*                           CSP_GPIO_PORT_NBR_01
*                           CSP_GPIO_PORT_NBR_A
*                           CSP_GPIO_PORT_NBR_B
*
*                (2) Some architectures multiplex general purpose pins with peripheral functions the 
*                    'fnct' parameter defines the GPIO function. 
*
*                   (a) GPIO function identifier can be found in csp.h:
*
*                           CSP_GPIO_FNCT_00    Pins are controlled by the GPIO controller
*                           CSP_GPIO_FNCT_01    Pins are controlled by the Multi-Function Interface function
*
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_GPIO_Cfg (CSP_DEV_NBR    port_nbr,
                           CSP_GPIO_MSK   pins,
                           CSP_OPT        dir,
                           CSP_OPT_FLAGS  drv_mode,
                           CPU_BOOLEAN    int_en,
                           CSP_OPT        int_pol,
                           CSP_OPT        fnct)
{
    CPU_INT32U   port_addr;
    CPU_SR_ALLOC();
    CPU_BOOLEAN  err;
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return (DEF_FAIL);
    }
#endif
        
    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    switch (fnct) {
        case CSP_GPIO_FNCT_00:             
             DEF_BIT_CLR(CSP_GPIO_REG_AFSEL(port_addr), pins);  /* Pins are controller by GPIO controller.              */
             DEF_BIT_SET(CSP_GPIO_REG_DR2R(port_addr), pins);   /* Pins strength are 2-mA Driven.                       */
             DEF_BIT_SET(CSP_GPIO_REG_ODEN(port_addr), pins);
             break;
        
        default:
             break;
    } 
    
    CPU_CRITICAL_ENTER();
    if (dir == CSP_GPIO_DIR_IN) {
        DEF_BIT_CLR(CSP_GPIO_REG_DIR(port_addr), pins);
        if (DEF_BIT_IS_SET_ANY(drv_mode, CSP_GPIO_FLAG_MODE_PULLUP | CSP_GPIO_FLAG_MODE_PULLDOWN)) {
            if (DEF_BIT_IS_SET(drv_mode, CSP_GPIO_FLAG_MODE_PULLUP)) {
                DEF_BIT_SET(CSP_GPIO_REG_PUR(port_addr), pins);
            } else {
                DEF_BIT_SET(CSP_GPIO_REG_PDR(port_addr), pins);
            }
        }        
    } else {
        DEF_BIT_SET(CSP_GPIO_REG_DIR(port_addr), pins);
        if (DEF_BIT_IS_SET(drv_mode, CSP_GPIO_FLAG_MODE_OPEN_DRAIN)) {
            DEF_BIT_SET(CSP_GPIO_REG_ODR(port_addr), pins);
        } else {
            DEF_BIT_CLR(CSP_GPIO_REG_ODR(port_addr), pins);
        }
    }
    CPU_CRITICAL_EXIT();
                        
    err = DEF_TRUE;
    
    return (err); 
}

/*
*********************************************************************************************************
*                                          CSP_GPIO_BitClr()
*
* Description : Clear a group of pins for a specific I/O port.
*
* Argument(s) : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
*               pins        Bit mask specifying which pins to clear.
*
* Return(s)   : None
*
* Caller(s)   : Application.
*
* Note(s)     : None
*********************************************************************************************************
*/

void  CSP_GPIO_BitClr (CSP_DEV_NBR   port_nbr,
                       CSP_GPIO_MSK  pins)
{
    CPU_INT32U   port_addr;
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return;
    }
#endif
    
    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    
    DEF_BIT_CLR(CSP_GPIO_REG_DATA(port_addr, pins), pins);      
}


/*
*********************************************************************************************************
*                                         CSP_GPIO_BitSet()
*
* Description : Set a group of pins for a specific I/O port
*
* Argument(s) : port_nbr   GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
*               pins       Bit mask specifying which pins to set.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_GPIO_BitSet (CSP_DEV_NBR   port_nbr,
                       CSP_GPIO_MSK  pins)
{
    CPU_INT32U   port_addr;
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return;
    }
#endif
    
    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    
    DEF_BIT_SET(CSP_GPIO_REG_DATA(port_addr, pins), pins);         
}


/*
*********************************************************************************************************
*                                         CSP_GPIO_BitToggle()
*
* Description : Toggle a group of pins for a specific I/O port.
*
* Argument(s) : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
*               pins        Bit mask specifying which pins to Toggle.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_GPIO_BitToggle (CSP_DEV_NBR   port_nbr,
                          CSP_GPIO_MSK  pins)
{    
    CSP_GPIO_MSK  pins_clr;
    CSP_GPIO_MSK  pins_set;
    CSP_GPIO_MSK  port_val;
    CPU_INT32U    port_addr;
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return;
    }
#endif
    
    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    port_val  = CSP_GPIO_Rd(port_nbr);
    pins_clr  = ( port_val) & pins;
    pins_set  = (~port_val) & pins;
    
    DEF_BIT_CLR(CSP_GPIO_REG_DATA(port_addr, pins), pins_clr);
    DEF_BIT_SET(CSP_GPIO_REG_DATA(port_addr, pins), pins_set);    
}   


/*
*********************************************************************************************************
*                                         CSP_GPIO_Rd()
*
* Description : Read the current value of the port.
*
* Argument(s) : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
* Return(s)   : The current value of the port.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CSP_GPIO_MSK  CSP_GPIO_Rd (CSP_DEV_NBR  port_nbr)
{
    CSP_GPIO_MSK  port_val;
    CPU_INT32U    port_addr;    

#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return ((CSP_GPIO_MSK)0u);
    }
#endif

    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    port_val  = CSP_GPIO_REG_DATA(port_addr, DEF_BIT_FIELD(8u, 0u));
    
    return (port_val);
}


/*
*********************************************************************************************************
*                                            CSP_GPIO_Wr()
*
* Description : Write a value to a specific port.
*
* Argument(s) : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
*               val         Value to write.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_GPIO_Wr (CSP_DEV_NBR   port_nbr,
                   CSP_GPIO_MSK  val)
{
    CSP_GPIO_MSK  pins_clr;
    CSP_GPIO_MSK  pins_set;
    CPU_INT32U    port_addr;    
    
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    if ((port_nbr == CSP_GPIO_PORT_NBR_I) ||
        (port_nbr >= CSP_GPIO_PORT_NBR_K)) {
        return;
    }
#endif
    
    port_addr = CSP_GPIO_GetPortAddr(port_nbr);
    pins_set  =  val;
    pins_clr  = ~val;
    
    CSP_GPIO_REG_DATA(port_addr, DEF_BIT_FIELD(8u, 0u)) = pins_clr;
    CSP_GPIO_REG_DATA(port_addr, DEF_BIT_FIELD(8u, 0u)) = pins_set;
}


/*
*********************************************************************************************************
*                                         CSP_GPIO_IntClr()
*
* Description : Clear pending interrupts for a specific port.
*
* Argument(s) : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CSP_GPIO_MSK  CSP_GPIO_IntClr (CSP_DEV_NBR  port_nbr)
                   
{
    CSP_GPIO_MSK  int_stat;
    
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)     
    /* $$$$ Insert code to validate arguments.                                    */
#endif
    
    int_stat = 0u;
    
    return (int_stat);
}

/*
*********************************************************************************************************
*                                        CSP_GPIO_IntStatGet()
*
* Description : Read the port interrupt status state.
*
* Argument(s) : port_nbr    GPIO port number (CSP_GPIO_PORT_NBR_XX).
*
* Return(s)   : port_nbr    GPIO port number. (See 'CSP_GPIO_Cfg()' note #1).
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CSP_GPIO_MSK  CSP_GPIO_IntStatGet (CSP_DEV_NBR  port_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    /* $$$$ Insert code to validate arguments.                                    */
#endif

    return ((CSP_GPIO_MSK)0);
}
    
/*
*********************************************************************************************************
*                                       CSP_GPIO_GetPortAddr()
*
* Description : Get the LM3Sxxxx GPIO controller base address base on the port number for the Advanced
*               Peripheral Bus(APB).
*
* Argument(s) : port    I/O port number
*
* Return(s)   : none
*
* Caller(s)   : CSP_GPIO_Cfg()
*
* Note(s)     : (1) The port configuration and the base address are defined in the device specific header file
*                   csp_dev.h
*********************************************************************************************************
*/

static  CPU_INT32U  CSP_GPIO_GetPortAddr (CSP_DEV_NBR port)
{
    CPU_INT32U  port_addr;

    
    switch (port) {
        case CSP_GPIO_PORT_NBR_A:
             port_addr = CSP_GPIO_REG_APB_PORT_A_BASE_ADDR; 
             break;

        case CSP_GPIO_PORT_NBR_B:
             port_addr = CSP_GPIO_REG_APB_PORT_B_BASE_ADDR; 
             break;

        case CSP_GPIO_PORT_NBR_C:
             port_addr = CSP_GPIO_REG_APB_PORT_C_BASE_ADDR; 
             break;

        case CSP_GPIO_PORT_NBR_D:
             port_addr = CSP_GPIO_REG_APB_PORT_D_BASE_ADDR; 
             break;

        case CSP_GPIO_PORT_NBR_E:
             port_addr = CSP_GPIO_REG_APB_PORT_E_BASE_ADDR; 
             break;
             
        case CSP_GPIO_PORT_NBR_F:
             port_addr = CSP_GPIO_REG_APB_PORT_F_BASE_ADDR; 
             break;
             
        case CSP_GPIO_PORT_NBR_G:
             port_addr = CSP_GPIO_REG_APB_PORT_G_BASE_ADDR; 
             break;
             
        case CSP_GPIO_PORT_NBR_H:
             port_addr = CSP_GPIO_REG_APB_PORT_H_BASE_ADDR; 
             break;
             
        case CSP_GPIO_PORT_NBR_J:
             port_addr = CSP_GPIO_REG_APB_PORT_J_BASE_ADDR; 
             break;
             
        default:
             port_addr = 0u;
             break;             
    }           
    
    return (port_addr);
}
