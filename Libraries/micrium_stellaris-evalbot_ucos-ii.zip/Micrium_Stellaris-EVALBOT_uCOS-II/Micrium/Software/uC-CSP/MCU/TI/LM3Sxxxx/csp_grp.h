/*
*********************************************************************************************************
*                                             uC/CSP
*                                        Chip Support Package
*
*                            (c) Copyright 2010; Micrium, Inc.; Weston, FL
*                         (c) Copyright 2003-2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved. Protected by international copyright laws.
*
*               uC/CSP is provided in source form to registered licensees ONLY.  It is
*               illegal to distribute this source code to any third party unless you receive
*               written permission by an authorized Micrium representative.  Knowledge of
*               the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*
*                                       FAMILY DEFINITION & API
*                                 TEXAS INSTRUMENTS LM3Sxxxx FAMILY
*
* Filename      : csp_grp.h
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
* Note(s)       : (1) The following products are supported by this family definition.
*
*
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               MODULE
*********************************************************************************************************
*/

#ifndef  CSP_GRP_MODULE_PRESENT
#define  CSP_GRP_MODULE_PRESENT


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               EXTERNS
*********************************************************************************************************
*/

#ifdef   CSP_GRP_MODULE
#define  CSP_GRP_EXT
#else
#define  CSP_GRP_EXT  extern
#endif


/*
*********************************************************************************************************
*                                        DEFAULT CONFIGURATION
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                         FAMILY IDENTIFIERS
*********************************************************************************************************
*/

#define  CSP_GRP_ID_LM3SXXXX
#define  CSP_GRP_NAME                     "LM3Sxxxx"

/*
*********************************************************************************************************
*                                 INTERRUPT CONTROLLER DEVICE NUMBERS
*********************************************************************************************************
*/

#define  CSP_INT_CTRL_NBR_MAIN                  (CSP_DEV_NBR)(0u)


/*
*********************************************************************************************************
*                                          INTERRUPT SOURCES
*
* Note(s) : (1) Interrupt controller sources #define's use the following standard:
*
*               #define  CSP_INT_SRC_NBR_<PER>_<PER_NBR>_<EVENT>
*
*               where 
*
*                   <PER>      Peripheral name (UART, ETHER, DMA, USB, etc)
*                   <EVENT>    Interrupt event (RX, TX, MATCH, ALERT, TO, etc)
*                              Empty for multiple events interrupts.
*                   <PER_NBR>  Peripheral number. (00, 01, 02, etc)
*
*              #define  CSP_INT_SRC_NBR_UART_00_RX    UART 00 receive interrupt.
*              #define  CSP_INT_SRC_NBR_UART_00_TX    UART 01 receive interrupt. 
*
*            (2) 'CSP_INT_SRC_NBR_MAX' defines maximum number of interrupts in the interrupt controller.
*********************************************************************************************************
*/

#define  CSP_INT_SRC_NBR_GPIO_A                     (CSP_DEV_NBR)(  0u)        /* GPIO Port A.                                        */
#define  CSP_INT_SRC_NBR_GPIO_B                     (CSP_DEV_NBR)(  1u)        /* GPIO Port B.                                        */
#define  CSP_INT_SRC_NBR_GPIO_C                     (CSP_DEV_NBR)(  2u)        /* GPIO Port C.                                        */
#define  CSP_INT_SRC_NBR_GPIO_D                     (CSP_DEV_NBR)(  3u)        /* GPIO Port D.                                        */
#define  CSP_INT_SRC_NBR_GPIO_E                     (CSP_DEV_NBR)(  4u)        /* GPIO Port E.                                        */
#define  CSP_INT_SRC_NBR_UART_00                    (CSP_DEV_NBR)(  5u)        /* UART0.                                              */
#define  CSP_INT_SRC_NBR_UART_01                    (CSP_DEV_NBR)(  6u)        /* UART1.                                              */
#define  CSP_INT_SRC_NBR_SSI_00                     (CSP_DEV_NBR)(  7u)        /* Synchronous Serial Interface(SSI0).                 */
#define  CSP_INT_SRC_NBR_I2C_00                     (CSP_DEV_NBR)(  8u)        /* I2C0.                                               */
#define  CSP_INT_SRC_NBR_PWM_FAULT                  (CSP_DEV_NBR)(  9u)        /* PWM Fault.                                          */
#define  CSP_INT_SRC_NBR_PWM_GEN_00                 (CSP_DEV_NBR)( 10u)        /* PWM Generator 0.                                    */
#define  CSP_INT_SRC_NBR_PWM_GEN_01                 (CSP_DEV_NBR)( 11u)        /* PWM Generator 1.                                    */
#define  CSP_INT_SRC_NBR_PWM_GEN_02                 (CSP_DEV_NBR)( 12u)        /* PWM Generator 2.                                    */
#define  CSP_INT_SRC_NBR_QEI_00                     (CSP_DEV_NBR)( 13u)        /* Quadrature Encoder Interface(QEI0).                 */
#define  CSP_INT_SRC_NBR_ADC_00_SEQ_00              (CSP_DEV_NBR)( 14u)        /* ADC0 Sequence 0.                                    */
#define  CSP_INT_SRC_NBR_ADC_00_SEQ_01              (CSP_DEV_NBR)( 15u)        /* ADC0 Sequence 1.                                    */
#define  CSP_INT_SRC_NBR_ADC_00_SEQ_02              (CSP_DEV_NBR)( 16u)        /* ADC0 Sequence 2.                                    */
#define  CSP_INT_SRC_NBR_ADC_00_SEQ_03              (CSP_DEV_NBR)( 17u)        /* ADC0 Sequence 3.                                    */
#define  CSP_INT_SRC_NBR_WDT_00                     (CSP_DEV_NBR)( 18u)        /* Watchdog Timers 0 and 1.                            */
#define  CSP_INT_SRC_NBR_TMR_0A                     (CSP_DEV_NBR)( 19u)        /* Timer 0A.                                           */
#define  CSP_INT_SRC_NBR_TMR_0B                     (CSP_DEV_NBR)( 20u)        /* Timer 0B.                                           */
#define  CSP_INT_SRC_NBR_TMR_1A                     (CSP_DEV_NBR)( 21u)        /* Timer 1A.                                           */
#define  CSP_INT_SRC_NBR_TMR_1B                     (CSP_DEV_NBR)( 22u)        /* Timer 1B.                                           */
#define  CSP_INT_SRC_NBR_TMR_2A                     (CSP_DEV_NBR)( 23u)        /* Timer 2A.                                           */
#define  CSP_INT_SRC_NBR_TMR_2B                     (CSP_DEV_NBR)( 24u)        /* Timer 2B.                                           */
#define  CSP_INT_SRC_NBR_COMP_00                    (CSP_DEV_NBR)( 25u)        /* Analog Comparator 0.                                */
#define  CSP_INT_SRC_NBR_COMP_01                    (CSP_DEV_NBR)( 26u)        /* Analog Comparator 1.                                */
#define  CSP_INT_SRC_NBR_COMP_02                    (CSP_DEV_NBR)( 27u)        /* Analog Comparator 2.                                */
#define  CSP_INT_SRC_NBR_SYS_CTRL_00                (CSP_DEV_NBR)( 28u)        /* System Control.                                     */
#define  CSP_INT_SRC_NBR_FLASH_CTRL_00              (CSP_DEV_NBR)( 29u)        /* Flash Memory Control.                               */
#define  CSP_INT_SRC_NBR_GPIO_F                     (CSP_DEV_NBR)( 30u)        /* GPIO Port F.                                        */
#define  CSP_INT_SRC_NBR_GPIO_G                     (CSP_DEV_NBR)( 31u)        /* GPIO Port G.                                        */
#define  CSP_INT_SRC_NBR_GPIO_H                     (CSP_DEV_NBR)( 32u)        /* GPIO Port H.                                        */
#define  CSP_INT_SRC_NBR_UART_02                    (CSP_DEV_NBR)( 33u)        /* UART2.                                              */
#define  CSP_INT_SRC_NBR_SSI_01                     (CSP_DEV_NBR)( 34u)        /* Synchronous Serial Interface(SSI1).                 */
#define  CSP_INT_SRC_NBR_TMR_3A                     (CSP_DEV_NBR)( 35u)        /* Timer 3A.                                           */
#define  CSP_INT_SRC_NBR_TMR_3B                     (CSP_DEV_NBR)( 36u)        /* Timer 3B.                                           */
#define  CSP_INT_SRC_NBR_I2C_01                     (CSP_DEV_NBR)( 37u)        /* I2C1.                                               */
#define  CSP_INT_SRC_NBR_QEI_01                     (CSP_DEV_NBR)( 38u)        /* Quadrature Encoder Interface(QEI1).                 */
#define  CSP_INT_SRC_NBR_CAN_00                     (CSP_DEV_NBR)( 39u)        /* CAN0.                                               */
#define  CSP_INT_SRC_NBR_CAN_01                     (CSP_DEV_NBR)( 40u)        /* CAN1.                                               */
#define  CSP_INT_SRC_NBR_RESERVED_00                (CSP_DEV_NBR)( 41u)        /* Reserved 0.                                         */
#define  CSP_INT_SRC_NBR_ETHER_00                   (CSP_DEV_NBR)( 42u)        /* Ethernet Controller.                                */
#define  CSP_INT_SRC_NBR_RESERVED_01                (CSP_DEV_NBR)( 43u)        /* Reserved 1.                                         */
#define  CSP_INT_SRC_NBR_USB_00                     (CSP_DEV_NBR)( 44u)        /* USB.                                                */
#define  CSP_INT_SRC_NBR_PMW_GEN_03                 (CSP_DEV_NBR)( 45u)        /* PWM Generator 3.                                    */
#define  CSP_INT_SRC_NBR_UDMA_SOFT_00               (CSP_DEV_NBR)( 46u)        /* uDMA Sofware.                                       */
#define  CSP_INT_SRC_NBR_UDMA_ERR_00                (CSP_DEV_NBR)( 47u)        /* uDMA Error.                                         */
#define  CSP_INT_SRC_NBR_ADC_01_SEQ_00              (CSP_DEV_NBR)( 48u)        /* ADC1 Sequence 0.                                    */
#define  CSP_INT_SRC_NBR_ADC_01_SEQ_01              (CSP_DEV_NBR)( 49u)        /* ADC1 Sequence 1.                                    */
#define  CSP_INT_SRC_NBR_ADC_01_SEQ_02              (CSP_DEV_NBR)( 50u)        /* ADC1 Sequence 2.                                    */
#define  CSP_INT_SRC_NBR_ADC_01_SEQ_03              (CSP_DEV_NBR)( 51u)        /* ADC1 Sequence 3.                                    */
#define  CSP_INT_SRC_NBR_I2S_00                     (CSP_DEV_NBR)( 52u)        /* I2S0.                                               */
#define  CSP_INT_SRC_NBR_EPI_00                     (CSP_DEV_NBR)( 53u)        /* External Peripheral Interface(EPI).                 */
#define  CSP_INT_SRC_NBR_GPIO_J                     (CSP_DEV_NBR)( 54u)        /* GPIO Port J.                                        */

#define  CSP_INT_SRC_NBR_MAX                        (CSP_DEV_NBR)( 55u)        /* Maximum number of interrupts.                       */

/*
*********************************************************************************************************
*                                     PERIPHERALS CLOCKS DEFINES
*
* Note(s) : (1) The peripheral's clock #define's use the following standard.
*        
*                   #define  CSP_PM_PER_CLK_NBR_<PER>_<PER_NBR>
*
*                   where,
*
*                   <PER>      Peripheral clock name.
*                   <PER_NBR>  Peripheral clock number identifier.
*
*********************************************************************************************************
*/

#define  CSP_PM_PER_CLK_NBR_UART_00                 (CSP_DEV_NBR)(  0u)         /* UART module 0                                      */
#define  CSP_PM_PER_CLK_NBR_UART_01                 (CSP_DEV_NBR)(  1u)         /* UART module 1                                      */
#define  CSP_PM_PER_CLK_NBR_UART_02                 (CSP_DEV_NBR)(  2u)         /* UART module 2                                      */
#define  CSP_PM_PER_CLK_NBR_SSI_00                  (CSP_DEV_NBR)(  4u)         /* Synchronous Serial Interface module 0              */
#define  CSP_PM_PER_CLK_NBR_SSI_01                  (CSP_DEV_NBR)(  5u)         /* Synchronous Serial Interface module 1              */
#define  CSP_PM_PER_CLK_NBR_QEI_00                  (CSP_DEV_NBR)(  8u)         /* Quadrature Encoder Interface module 0              */
#define  CSP_PM_PER_CLK_NBR_QEI_01                  (CSP_DEV_NBR)(  9u)         /* Quadrature Encoder Interface module 1              */
#define  CSP_PM_PER_CLK_NBR_I2C_00                  (CSP_DEV_NBR)( 12u)         /* I2C module 0                                       */
#define  CSP_PM_PER_CLK_NBR_I2C_01                  (CSP_DEV_NBR)( 14u)         /* I2C module 1                                       */
#define  CSP_PM_PER_CLK_NBR_TMR_00                  (CSP_DEV_NBR)( 16u)         /* General Purporse Timer module 0                    */
#define  CSP_PM_PER_CLK_NBR_TMR_01                  (CSP_DEV_NBR)( 17u)         /* General Purporse Timer module 1                    */
#define  CSP_PM_PER_CLK_NBR_TMR_02                  (CSP_DEV_NBR)( 18u)         /* General Purporse Timer module 2                    */
#define  CSP_PM_PER_CLK_NBR_TMR_03                  (CSP_DEV_NBR)( 19u)         /* General Purporse Timer module 3                    */
#define  CSP_PM_PER_CLK_NBR_COMP_00                 (CSP_DEV_NBR)( 24u)         /* Analog comparator 0                                */
#define  CSP_PM_PER_CLK_NBR_COMP_01                 (CSP_DEV_NBR)( 25u)         /* Analog comparator 1                                */
#define  CSP_PM_PER_CLK_NBR_COMP_02                 (CSP_DEV_NBR)( 26u)         /* Analog comparator 2                                */
#define  CSP_PM_PER_CLK_NBR_I2S_00                  (CSP_DEV_NBR)( 28u)         /* I2S module 0                                       */
#define  CSP_PM_PER_CLK_NBR_EPI_00                  (CSP_DEV_NBR)( 30u)         /* External Peripheral Interface module 0             */

#define  CSP_PM_PER_CLK_RCGC2_OFFSET                (CSP_DEV_NBR)( 31u)
#define  CSP_PM_PER_CLK_NBR_GPIO_A                  (CSP_DEV_NBR)( 31u)         /* GPIO Port A                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_B                  (CSP_DEV_NBR)( 32u)         /* GPIO Port B                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_C                  (CSP_DEV_NBR)( 33u)         /* GPIO Port C                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_D                  (CSP_DEV_NBR)( 34u)         /* GPIO Port D                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_E                  (CSP_DEV_NBR)( 35u)         /* GPIO Port E                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_F                  (CSP_DEV_NBR)( 36u)         /* GPIO Port F                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_G                  (CSP_DEV_NBR)( 37u)         /* GPIO Port G                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_H                  (CSP_DEV_NBR)( 38u)         /* GPIO Port H                                        */
#define  CSP_PM_PER_CLK_NBR_GPIO_J                  (CSP_DEV_NBR)( 39u)         /* GPIO Port J                                        */
#define  CSP_PM_PER_CLK_NBR_UDMA_00                 (CSP_DEV_NBR)( 44u)         /* Micro-DMA                                          */
#define  CSP_PM_PER_CLK_NBR_USB_00                  (CSP_DEV_NBR)( 47u)         /* USB module 0                                       */
#define  CSP_PM_PER_CLK_NBR_EMAC_00                 (CSP_DEV_NBR)( 59u)         /* Ethernet MAC layer 0                               */
#define  CSP_PM_PER_CLK_NBR_EPHY_00                 (CSP_DEV_NBR)( 61u)         /* Ethernet PHY layer 0                               */

#define  CSP_PM_PER_CLK_RCGC0_OFFSET                (CSP_DEV_NBR)( 59u)
#define  CSP_PM_PER_CLK_NBR_WDT_00                  (CSP_DEV_NBR)( 62u)         /* WatchDog Timer module 0                            */
#define  CSP_PM_PER_CLK_NBR_ADC_00                  (CSP_DEV_NBR)( 75u)         /* ADC module 0                                       */
#define  CSP_PM_PER_CLK_NBR_ADC_01                  (CSP_DEV_NBR)( 76u)         /* ADC module 1                                       */
#define  CSP_PM_PER_CLK_NBR_PWM_00                  (CSP_DEV_NBR)( 79u)         /* PWM module 0                                       */
#define  CSP_PM_PER_CLK_NBR_CAN_00                  (CSP_DEV_NBR)( 83u)         /* CAN module 0                                       */
#define  CSP_PM_PER_CLK_NBR_CAN_01                  (CSP_DEV_NBR)( 84u)         /* CAN module 1                                       */
#define  CSP_PM_PER_CLK_NBR_WDT_01                  (CSP_DEV_NBR)( 87u)         /* Watchdog Timer module 1                            */

#define  CSP_PM_PER_CLK_NBR_MAX                     (CSP_DEV_NBR)( 88u)         /* Maximum number of peripherals clocks.              */



/*
*********************************************************************************************************
*                                        SYSTEM CLOCKS DEFINES
*
* Note(s) : (1) The system clock #define's use the following standard.
*        
*                   #define  CSP_PM_SYS_CLK_NBR_<SYS>_<SYS_NBR>
*
*                   where,
*
*                   <SYS>      System clock number name.
*                   <SYS_NBR>  System clock number identifier.
*
*********************************************************************************************************
*/


#define  CSP_PM_SYS_CLK_NBR_USB_00                  (CSP_DEV_NBR)(  0u)        /* USB Clock                                             */
#define  CSP_PM_SYS_CLK_NBR_SYS_00                  (CSP_DEV_NBR)(  1u)        /* SYSTEM clock                                          */
#define  CSP_PM_SYS_CLK_NBR_ADC_00                  (CSP_DEV_NBR)(  2u)        /* ADC clock                                             */
#define  CSP_PM_SYS_CLK_NBR_PMW_00                  (CSP_DEV_NBR)(  3u)        /* PWM clock                                             */
#define  CSP_PM_SYS_CLK_NBR_I2S_RX_00               (CSP_DEV_NBR)(  4u)        /* I2S Receive MCLK                                      */
#define  CSP_PM_SYS_CLK_NBR_I2S_TX_00               (CSP_DEV_NBR)(  5u)        /* I2S Transmit MCLK                                     */

#define  CSP_PM_SYS_CLK_NBR_MAX                     (CSP_DEV_NBR)(  6u)        /* Maximum number of peripherals clocks.                 */

/*
*********************************************************************************************************
*                                           GPIO PORT MASK
*********************************************************************************************************
*/

typedef  CPU_INT32U  CSP_GPIO_MSK;                              /* GPIOs port are 16-bits.                              */

/*
*********************************************************************************************************
*                                        TIMER VALUE DATA TYPE
*********************************************************************************************************
*/

typedef  CPU_INT16U  CSP_TMR_VAL;                               /* Timers are 16-bits wide.                             */

/*
*********************************************************************************************************
*                                          GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                              MACRO'S
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                           LM3Sxxxx FAMILY API
* 
* Note(s) : (1) Application code written using this API is 100% compatible through all devices in the same
*               LM3Sxxxx series family.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                        CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                             MODULE END
*********************************************************************************************************
*/

#endif                                                          /* End of CSP_GRP module include.                      */

