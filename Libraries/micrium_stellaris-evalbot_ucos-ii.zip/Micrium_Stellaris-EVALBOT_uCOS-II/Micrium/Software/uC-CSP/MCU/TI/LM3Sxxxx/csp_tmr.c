/*
*********************************************************************************************************
*                                             uC/CSP
*                                        Chip Support Package
*
*                            (c) Copyright 2010; Micrium, Inc.; Weston, FL
*                         (c) Copyright 2003-2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved. Protected by international copyright laws.
*
*               uC/CSP is provided in source form to registered licensees ONLY.  It is
*               illegal to distribute this source code to any third party unless you receive
*               written permission by an authorized Micrium representative.  Knowledge of
*               the source code may NOT be used to develop a similar product.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*
*                                          TIMER MANAGEMENT
*                                 TEXAS INSTRUMENTS LM3Sxxxx FAMILY
* 
* Filename      : csp_tmr.h
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
* Note(s)       : (1) The following products are supported by this family definition.
*
*
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define  CSP_TMR_MODULE
#include <csp.h>

/*
*********************************************************************************************************
*                                    REGISTER & BIT-FIELD DEFINITION
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL MACRO's
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*********************************************************************************************************
*                                           LOCAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                        CSP_TmrInit()
*
* Description : Initialize & disable all the timers.
*                   
* Argument(s) : none.
*
* Return(s)   : none
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  CSP_TmrInit (void)
{

}


/*
*********************************************************************************************************
*                                            CSP_TmrCfg()
*
* Description : Configure periodic or free running timer. 
*                   
* Argument(s) : tmr_nbr    Timer number identifier (see note #1).
*
*               freq       Periodic timer frequency. (see note #2)
*                          
* Return(s)   : DEF_OK,   If the timer was configured correctly,
 *              DEF_FAIL, otherwise.
*
* Caller(s)   : Application.
*
* Note(s)     : (1) Timer number identifier are defined in 'csp.h'
*
*                       CSP_TMR_NBR_00     
*                       CSP_TMR_NBR_01
*                              .
*                              .
*                              .
*                       CSP_TMR_NBR_xx
*
*                        (a) 'CSP_TMR_NBR_SYS_TICK' is used for microcontrollers with system tick timers.
*               
*               (2) If 'freq' == 0 Timer is configured as free-running timer.
*                   If 'freq' > 0  Timer will be configured to generate a interrupt event every
*                   (1/freq) seconds.
*
*               (3) If the timer is configured in periodic mode, the interrupt handler needs
*                   to be installed first by the application in the interrupt controller.
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_TmrCfg (CSP_DEV_NBR  tmr_nbr,
                         CPU_INT32U   freq)
{   
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    /* $$$$ Insert code to validate arguments.                                    */
#endif
         
    return (DEF_OK);
}



/*
*********************************************************************************************************
*                                            CSP_TmrOutCmpCfg()
*
* Description : Configure a timer for compare mode. 
*                   
* Argument(s) : tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
*               pin_nbr    Pin number.
*
*               pin_action  Output compare pin action
*
*                              CSP_TMR_OPT_PIN_OUT_NONE      Do nothing.
*                              CSP_TMR_OPT_PIN_OUT_CLR       Clear  the correspoding  external pin for output compare.
*                              CSP_TMR_OPT_PIN_OUT_SET       Set    the correspondin  external pin for output compare.                                                       
*                              CSP_TMR_OPT_PIN_OUT_TOGGLE    Toggle the corresponding external pin for output compare.
*
* Return(s)   : DEF_OK,   If the timer was configured correctly in compare mode,
*               DEF_FAIL, otherwise.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CPU_BOOLEAN  CSP_TmrOutCmpCfg (CSP_DEV_NBR  tmr_nbr,
                               CSP_DEV_NBR  pin,
                               CSP_OPT      pin_action,
                               CPU_INT32U   freq)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    /* $$$$ Insert code to validate arguments.                                    */
#endif
    
    return (DEF_OK);
}



/*
*********************************************************************************************************
*                                           CSP_TmrIntClr()
*
* Description : Clear a periodic timer interrupt.
*                   
* Argument(s) : tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_TmrIntClr (CSP_DEV_NBR tmr_nbr)
{

}


/*
*********************************************************************************************************
*                                            CSP_TmrRst()
*
* Description : Resets a timer.
*                   
* Argument(s) : tmr_nbr    tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_TmrRst (CSP_DEV_NBR  tmr_nbr)
{    

}


/*
*********************************************************************************************************
*                                             CSP_TmrRd()
*
* Description : Read the current value of a timer.
*                   
* Argument(s) : tmr_nbr    tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
* Return(s)   : The current value of the timer.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

CSP_TMR_VAL  CSP_TmrRd  (CSP_DEV_NBR  tmr_nbr)
{
#if (CSP_CFG_ARG_CHK_EN == DEF_ENABLED)
    /* $$$$ Insert code to validate arguments.                                    */
#endif
        
    return (0u);
}


/*
*********************************************************************************************************
*                                     CSP_TmrStart()
*
* Description : Start a timer.
*                   
* Argument(s) : tmr_nbr    tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_TmrStart (CSP_DEV_NBR  tmr_nbr)
{

}


/*
*********************************************************************************************************
*                                            CSP_TmrStop()
*
* Description : Stop a timer.
*                   
* Argument(s) : tmr_nbr    tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_TmrStop  (CSP_DEV_NBR  tmr_nbr)
{

}


/*
*********************************************************************************************************
*                                             CSP_TmrWr()
*
* Description : Write a value to a timer.
*                   
* Argument(s) : tmr_nbr    tmr_nbr    Timer number identifier (see 'CSP_TmrCfg' note #1).
*
*               tmr_val    value to write.
*
* Return(s)   : None.
*
* Caller(s)   : Application.
*
* Note(s)     : None.
*********************************************************************************************************
*/

void  CSP_TmrWr  (CSP_DEV_NBR  tmr_nbr,
                  CSP_TMR_VAL  tmr_val)
{    
    (void)tmr_nbr;
    (void)tmr_val;
}
