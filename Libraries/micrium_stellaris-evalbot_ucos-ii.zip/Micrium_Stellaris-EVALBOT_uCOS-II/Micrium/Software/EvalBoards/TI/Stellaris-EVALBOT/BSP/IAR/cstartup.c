/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                              (c) Copyright 2009; Micrium, Inc.; Weston, FL
*
*                   All rights reserved.  Protected by international copyright laws.
*                   Knowledge of the source code may not be used to write a similar
*                   product.  This file may only be used in accordance with a license
*                   and should not be redistributed in any way.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                         STARTUP CODE
*
*                                 Texas Instruments LM3S9B92
*
* Filename      : cstarup.c
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
*/

#include <includes.h>


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/

typedef  union {
    CPU_FNCT_VOID   Fnct;
    void           *Ptr;
} APP_INTVECT_ELEM;



/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

#pragma language=extended
#pragma segment="CSTACK"

static  void  App_NMI_ISR        (void);

static  void  App_Fault_ISR      (void);

static  void  App_BusFault_ISR   (void);

static  void  App_UsageFault_ISR (void);

static  void  App_MemFault_ISR   (void);

static  void  App_Spurious_ISR   (void);

extern  void  __iar_program_start(void);


/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                  EXCEPTION / INTERRUPT VECTOR TABLE
*
* Note(s) : (1) The Cortex-M3 may have up to 256 external interrupts, which are the final entries in the
*               vector table.  The LM3Sxxxx has 54 external interrupt vectors.
*
*           (2) Interrupts vector 2-13 are implemented in this file as infinite loop for debuging
*               purposes only. The application might implement a recover procedure if it is needed.
*
*           (3) OS_CPU_PendSVHandler() and OS_CPU_SysTickHandler() are implemented in the generic OS
*               port.
*********************************************************************************************************
*/

__root  const  APP_INTVECT_ELEM  __vector_table[] @ ".intvec" = {
    { .Ptr = (void *)__sfe( "CSTACK" )},                        /*  0, SP start value.                                  */
    __iar_program_start,                                        /*  1, PC start value.                                  */
    App_NMI_ISR,                                                /*  2, NMI.                                             */
    App_Fault_ISR,                                              /*  3, Hard Fault.                                      */
    App_MemFault_ISR,                                           /*  4, Memory Management.                               */
    App_BusFault_ISR,                                           /*  5, Bus Fault.                                       */
    App_UsageFault_ISR,                                         /*  6, Usage Fault.                                     */
    App_Spurious_ISR,                                           /*  7, Reserved.                                        */
    App_Spurious_ISR,                                           /*  8, Reserved.                                        */
    App_Spurious_ISR,                                           /*  9, Reserved.                                        */
    App_Spurious_ISR,                                           /* 10, Reserved.                                        */
    App_Spurious_ISR,                                           /* 11, SVCall.                                          */
    App_Spurious_ISR,                                           /* 12, Debug Monitor.                                   */
    App_Spurious_ISR,                                           /* 13, Reserved.                                        */
    OS_CPU_PendSVHandler,                                       /* 14, PendSV Handler.                                  */
    OS_CPU_SysTickHandler,                                      /* 15, uC/OS-II Tick ISR Handler.                       */

    OS_CPU_IntHandler,                                          /* 16, INTISR[  0]  GPIO Port A.                        */
    OS_CPU_IntHandler,                                          /* 17, INTISR[  1]  GPIO Port B.                        */
    OS_CPU_IntHandler,                                          /* 18, INTISR[  2]  GPIO Port C.                        */
    OS_CPU_IntHandler,                                          /* 19, INTISR[  3]  GPIO Port D.                        */
    OS_CPU_IntHandler,                                          /* 20, INTISR[  4]  GPIO Port E.                        */
    OS_CPU_IntHandler,                                          /* 21, INTISR[  5]  UART0.                              */
    OS_CPU_IntHandler,                                          /* 22, INTISR[  6]  UART1.                              */
    OS_CPU_IntHandler,                                          /* 23, INTISR[  7]  Synchronous Serial Interface(SSI0). */
    OS_CPU_IntHandler,                                          /* 24, INTISR[  8]  I2C0.                               */
    OS_CPU_IntHandler,                                          /* 25, INTISR[  9]  PWM Fault.                          */
    OS_CPU_IntHandler,                                          /* 26, INTISR[ 10]  PWM Generator 0.                    */
    OS_CPU_IntHandler,                                          /* 27, INTISR[ 11]  PWM Generator 1.                    */
    OS_CPU_IntHandler,                                          /* 28, INTISR[ 12]  PWM Generator 2.                    */
    OS_CPU_IntHandler,                                          /* 29, INTISR[ 13]  Quadrature Encoder Interface(QEI0). */
    OS_CPU_IntHandler,                                          /* 30, INTISR[ 14]  ADC0 Sequence 0.                    */
    OS_CPU_IntHandler,                                          /* 31, INTISR[ 15]  ADC0 Sequence 1.                    */

    OS_CPU_IntHandler,                                          /* 32, INTISR[ 16]  ADC0 Sequence 2.                    */
    OS_CPU_IntHandler,                                          /* 33, INTISR[ 17]  ADC0 Sequence 3.                    */
    OS_CPU_IntHandler,                                          /* 34, INTISR[ 18]  Watchdog Timers 0 and 1.            */
    OS_CPU_IntHandler,                                          /* 35, INTISR[ 19]  Timer 0A.                           */
    OS_CPU_IntHandler,                                          /* 36, INTISR[ 20]  Timer 0B.                           */
    OS_CPU_IntHandler,                                          /* 37, INTISR[ 21]  Timer 1A.                           */
    OS_CPU_IntHandler,                                          /* 38, INTISR[ 22]  Timer 1B.                           */
    OS_CPU_IntHandler,                                          /* 39, INTISR[ 23]  Timer 2A.                           */
    OS_CPU_IntHandler,                                          /* 40, INTISR[ 24]  Timer 2B.                           */
    OS_CPU_IntHandler,                                          /* 41, INTISR[ 25]  Analog Comparator 0.                */
    OS_CPU_IntHandler,                                          /* 42, INTISR[ 26]  Analog Comparator 1.                */
    OS_CPU_IntHandler,                                          /* 43, INTISR[ 27]  Analog Comparator 2.                */
    OS_CPU_IntHandler,                                          /* 44, INTISR[ 28]  System Control.                     */
    OS_CPU_IntHandler,                                          /* 45, INTISR[ 29]  Flash Memory Control.               */
    OS_CPU_IntHandler,                                          /* 46, INTISR[ 30]  GPIO Port F.                        */
    OS_CPU_IntHandler,                                          /* 47, INTISR[ 31]  GPIO Port G.                        */

    OS_CPU_IntHandler,                                          /* 48, INTISR[ 32]  GPIO Port H.                        */
    OS_CPU_IntHandler,                                          /* 49, INTISR[ 33]  UART2.                              */
    OS_CPU_IntHandler,                                          /* 50, INTISR[ 34]  Synchronous Serial Interface(SSI1). */
    OS_CPU_IntHandler,                                          /* 51, INTISR[ 35]  Timer 3A.                           */
    OS_CPU_IntHandler,                                          /* 52, INTISR[ 36]  Timer 3B.                           */
    OS_CPU_IntHandler,                                          /* 53, INTISR[ 37]  I2C1.                               */
    OS_CPU_IntHandler,                                          /* 54, INTISR[ 38]  Quadrature Encoder Interface(QEI1). */
    OS_CPU_IntHandler,                                          /* 55, INTISR[ 39]  CAN0.                               */
    OS_CPU_IntHandler,                                          /* 56, INTISR[ 40]  CAN1.                               */
    App_Spurious_ISR,                                           /* 57, INTISR[ 41]  Reserved 0.                         */
    OS_CPU_IntHandler,                                          /* 58, INTISR[ 42]  Ethernet Controller.                */
    App_Spurious_ISR,                                           /* 59, INTISR[ 43]  Reserved 1.                         */
    OS_CPU_IntHandler,                                          /* 60, INTISR[ 44]  USB.                                */
    OS_CPU_IntHandler,                                          /* 61, INTISR[ 45]  PWM Generator 3.                    */
    OS_CPU_IntHandler,                                          /* 62, INTISR[ 46]  uDMA Sofware.                       */
    OS_CPU_IntHandler,                                          /* 63, INTISR[ 47]  uDMA Error.                         */
    OS_CPU_IntHandler,                                          /* 64, INTISR[ 48]  ADC1 Sequence 0.                    */
    OS_CPU_IntHandler,                                          /* 65, INTISR[ 49]  ADC1 Sequence 1.                    */
    OS_CPU_IntHandler,                                          /* 66, INTISR[ 50]  ADC1 Sequence 2.                    */
    OS_CPU_IntHandler,                                          /* 67, INTISR[ 51]  ADC1 Sequence 3.                    */
    OS_CPU_IntHandler,                                          /* 68, INTISR[ 52]  I2S0.                               */
    OS_CPU_IntHandler,                                          /* 69, INTISR[ 53]  External Peripheral Interface(EPI). */
    OS_CPU_IntHandler,                                          /* 70, INTISR[ 54]  GPIO Port J.                        */
};


/*
*********************************************************************************************************
*                                            App_NMI_ISR()
*
* Description : Handle Non-Maskable Interrupt (NMI).
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : (1) Since the NMI is not being used, this serves merely as a catch for a spurious
*                   exception.
*********************************************************************************************************
*/

static  void  App_NMI_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}


/*
*********************************************************************************************************
*                                             App_Fault_ISR()
*
* Description : Handle hard fault.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_Fault_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}


/*
*********************************************************************************************************
*                                           App_BusFault_ISR()
*
* Description : Handle bus fault.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_BusFault_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}


/*
*********************************************************************************************************
*                                          App_UsageFault_ISR()
*
* Description : Handle usage fault.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_UsageFault_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}


/*
*********************************************************************************************************
*                                           App_MemFault_ISR()
*
* Description : Handle memory fault.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_MemFault_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}


/*
*********************************************************************************************************
*                                           App_Spurious_ISR()
*
* Description : Handle spurious interrupt.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This is an ISR.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_Spurious_ISR (void)
{
    while (DEF_TRUE) {
        ;
    }
}
