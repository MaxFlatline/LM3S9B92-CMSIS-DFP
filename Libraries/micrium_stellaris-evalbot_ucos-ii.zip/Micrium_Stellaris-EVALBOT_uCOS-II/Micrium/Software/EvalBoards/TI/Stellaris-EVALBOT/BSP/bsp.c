/*
*********************************************************************************************************
*                                     MICIRUM BOARD SUPPORT PACKAGE
*
*                             (c) Copyright 2011; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                        MICRIUM BOARD SUPPORT PACKAGE
*
*                                          Texas Instruments LM3S9B92
*                                                  on the
*                                      STELLARIS-EVALBOT evaluation board
*                                      
*
* Filename      : bsp.c
* Version       : V1.00
* Programmer(s) : FT
*                 FF
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#define  BSP_MODULE
#include  <bsp.h>
#include  <os_cpu.h>
#include  <includes.h>

/*
*********************************************************************************************************
*                                      REGISTER & BIT FIELD DEFINES
*********************************************************************************************************
*/

#define  BSP_REG_SYS_CTRL_BASE_ADDR                  (CPU_INT32U)(0x400FE000u)

#define  BSP_REG_SYS_CTRL_RIS                     (*(CPU_REG32 *)(BSP_REG_SYS_CTRL_BASE_ADDR + 0x050u))
#define  BSP_REG_SYS_CTRL_MISC                    (*(CPU_REG32 *)(BSP_REG_SYS_CTRL_BASE_ADDR + 0x058u))
#define  BSP_REG_SYS_CTRL_RCC                     (*(CPU_REG32 *)(BSP_REG_SYS_CTRL_BASE_ADDR + 0x060u))
#define  BSP_REG_SYS_CTRL_RCC2                    (*(CPU_REG32 *)(BSP_REG_SYS_CTRL_BASE_ADDR + 0x070u))

#define  BSP_BIT_MISC_PLLLMIS                       DEF_BIT_06
#define  BSP_BIT_RIS_PLLLRIS                        DEF_BIT_06

#define  BSP_BIT_RCC_MOSCDIS                        DEF_BIT_00
#define  BSP_BIT_RCC_IOSCDIS                        DEF_BIT_01
#define  BSP_BIT_RCC_OSCSRC_MASK                    DEF_BIT_FIELD(2u, 4u)
#define  BSP_BIT_RCC_OSCSRC_MOSC                    DEF_BIT_NONE
#define  BSP_BIT_RCC_OSCSRC_PIOSC                   DEF_BIT_MASK(1u, 4u)
#define  BSP_BIT_RCC_OSCSRC_PIOSC_DIV4              DEF_BIT_MASK(2u, 4u)
#define  BSP_BIT_RCC_OSCSRC_30k_HZ                  DEF_BIT_MASK(3u, 4u)
#define  BSP_BIT_RCC_XTAL_MASK                      DEF_BIT_FIELD(5u, 6u)
#define  BSP_BIT_RCC_XTAL_16MHZ                     DEF_BIT_MASK(0x15u, 6u)
#define  BSP_BIT_RCC_BYPASS                         DEF_BIT_11
#define  BSP_BIT_RCC_PWRDN                          DEF_BIT_13
#define  BSP_BIT_RCC_USESYSDIV                      DEF_BIT_22
#define  BSP_BIT_RCC_SYSDIV_MASK                    DEF_BIT_FIELD(4u, 23u)

#define  BSP_BIT_RCC2_OSCSRC_MASK                   DEF_BIT_FIELD(3u, 4u)
#define  BSP_BIT_RCC2_OSCSRC_MOSC                   DEF_BIT_NONE
#define  BSP_BIT_RCC2_OSCSRC_PIOSC                  DEF_BIT_MASK(1u, 4u)
#define  BSP_BIT_RCC2_OSCSRC_PIOSC_DIV4             DEF_BIT_MASK(2u, 4u)
#define  BSP_BIT_RCC2_OSCSRC_30k_HZ                 DEF_BIT_MASK(3u, 4u)
#define  BSP_BIT_RCC2_BYPASS2                       DEF_BIT_11
#define  BSP_BIT_RCC2_PWRDN2                        DEF_BIT_13
#define  BSP_BIT_RCC2_SYSDIV2LSB                    DEF_BIT_22
#define  BSP_BIT_RCC2_SYSDIV2_MASK                  DEF_BIT_FIELD(6u, 23u)
#define  BSP_BIT_RCC2_SYSDIV_2_5                    DEF_BIT_MASK(4u, 22u)
#define  BSP_BIT_RCC2_DIV400                        DEF_BIT_30
#define  BSP_BIT_RCC2_USERCC2                       DEF_BIT_31

/*
*********************************************************************************************************
*                                            GPIO DEFINES
*********************************************************************************************************
*/

#define  BSP_GPIO_PORTF_LED1                       DEF_BIT_04
#define  BSP_GPIO_PORTF_LED2                       DEF_BIT_05

#define  BSP_GPIO_PORTF_LED_GRP                   (BSP_GPIO_PORTF_LED1  |                    \
                                                   BSP_GPIO_PORTF_LED2)

/*
*********************************************************************************************************
*                                       EXTERN  GLOBAL VARIABLES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                           LOCAL DEFINES
*********************************************************************************************************
*/

#define  BSP_REG_MAX_TO                             0x00080000u;

/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*********************************************************************************************************
**                                        GLOBAL FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                         BSP_LowLevelInit()
*
* Description : Board Support Package Low Level Initialization.
*
* Argument(s) : none.
*
* Returns(s)  : none
*
* Caller(s)   : Startup code.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  BSP_LowLevelInit (void)
{

}


/*
*********************************************************************************************************
*                                          BSP_PreInit()
*
* Description : System Pre-Initialization. Initializes all peripherals that don't require OS services (LEDs, PBs)
*               or modules than need to be initialized before the OS (External memories).
*
* Argument(s) : none.
*
* Return(s)   : none.

* Caller(s)   : Application.
*
* Note(s)     : 1) Configuring the System clock to 80Mhz
*                  - See Table 5-7 in the Stellaris LM3S9B92 MCU Data Sheet.
*                  - Set DIV400 bit to divide PLL out by 2;
*                  - Set USERCC2 bit to override RCC register fields
*                  - Set the SYSDIV2 and SYSDIV2LSB according to Table 5-7
*                    SYSDIV2    = 0x02
*                    SYSDIV2LSB = 0
*********************************************************************************************************
*/

void  BSP_PreInit (void)
{
    CPU_REG32   reg_rcc;
    CPU_REG32   reg_rcc2;
    CPU_INT32U  reg_to;

    
    
    reg_rcc  = BSP_REG_SYS_CTRL_RCC;
    reg_rcc2 = BSP_REG_SYS_CTRL_RCC2;

    DEF_BIT_CLR(reg_rcc, BSP_BIT_RCC_USESYSDIV);                /* Cfg. MCU to run off a raw clock source               */    
    DEF_BIT_SET(reg_rcc, BSP_BIT_RCC_BYPASS);                   /* Bypass the PLL and system clock divider              */
    DEF_BIT_SET(reg_rcc2, BSP_BIT_RCC2_BYPASS2);
                
    BSP_REG_SYS_CTRL_RCC  = reg_rcc;                            /* Write the new values                                 */
    BSP_REG_SYS_CTRL_RCC2 = reg_rcc2;
    
                                                                /* Enable required oscillator                           */
    DEF_BIT_CLR(reg_rcc, BSP_BIT_RCC_MOSCDIS | BSP_BIT_RCC_IOSCDIS);
    BSP_REG_SYS_CTRL_RCC  = reg_rcc;
    
    reg_to = BSP_REG_MAX_TO;                                    /* Wait for oscillator to stabilize                     */
    while (reg_to > 0u) {
        reg_to--;
    }
                                                                /* Cfg XTAL = 16MHz                                     */
                                                                /* Select oscillator source and PLL normal operation    */
    DEF_BIT_CLR(reg_rcc, (BSP_BIT_RCC_XTAL_MASK | BSP_BIT_RCC_OSCSRC_MASK | BSP_BIT_RCC_PWRDN));
    DEF_BIT_CLR(reg_rcc2,(BSP_BIT_RCC2_USERCC2 | BSP_BIT_RCC2_OSCSRC_MASK | BSP_BIT_RCC2_PWRDN2));
    
    reg_rcc  |= (BSP_BIT_RCC_XTAL_16MHZ | BSP_BIT_RCC_OSCSRC_MOSC);
    reg_rcc2 |= (BSP_BIT_RCC2_USERCC2 | BSP_BIT_RCC2_OSCSRC_MOSC);
    
    DEF_BIT_SET(BSP_REG_SYS_CTRL_MISC, BSP_BIT_MISC_PLLLMIS);   /*  Clear PLL lock Masked Interrupt Status              */
    
    if (DEF_BIT_IS_SET(reg_rcc2, BSP_BIT_RCC2_USERCC2)) {
        BSP_REG_SYS_CTRL_RCC2 = reg_rcc2;
        BSP_REG_SYS_CTRL_RCC  = reg_rcc;
    } else {
        BSP_REG_SYS_CTRL_RCC  = reg_rcc;
        BSP_REG_SYS_CTRL_RCC2 = reg_rcc2;
    }
    
    reg_to = BSP_REG_MAX_TO;                                    /* Wait for new XTAL value & OSC source to take effect  */
    while (reg_to > 0u) {
        reg_to--;
    }
                                                                /* See Note 1                                           */
    DEF_BIT_CLR(reg_rcc, BSP_BIT_RCC_SYSDIV_MASK);
    DEF_BIT_CLR(reg_rcc2, BSP_BIT_RCC2_SYSDIV2_MASK | BSP_BIT_RCC2_SYSDIV2LSB);
    
    reg_rcc  |= (BSP_BIT_RCC2_SYSDIV_2_5 & BSP_BIT_RCC_SYSDIV_MASK) | BSP_BIT_RCC_USESYSDIV;
    reg_rcc2 |= (BSP_BIT_RCC2_SYSDIV_2_5 | BSP_BIT_RCC2_DIV400);
    
    reg_to = BSP_REG_MAX_TO;                                    /* Wait for PLL to Lock                                 */
    while ((DEF_BIT_IS_CLR(BSP_REG_SYS_CTRL_RIS, BSP_BIT_RIS_PLLLRIS)) &&
           (reg_to > 0u)) {
        reg_to--;
    }
                                                                /* Enable the use of the PLL                            */
    DEF_BIT_CLR(reg_rcc, BSP_BIT_RCC_BYPASS);
    DEF_BIT_CLR(reg_rcc2, BSP_BIT_RCC2_BYPASS2);    
    
    BSP_REG_SYS_CTRL_RCC  = reg_rcc;
    BSP_REG_SYS_CTRL_RCC2 = reg_rcc2;
    
    reg_to = BSP_REG_MAX_TO;
    while (reg_to > 0u) {
        reg_to--;
    }
     
    
    CSP_PM_PerClkEn(CSP_PM_PER_CLK_NBR_GPIO_F);    
                                                                /* ...Cfg. LEDs                                         */
    CSP_GPIO_Cfg((CSP_DEV_NBR  )CSP_GPIO_PORT_NBR_F,
                 (CSP_GPIO_MSK )BSP_GPIO_PORTF_LED_GRP,
                 (CSP_OPT      )CSP_GPIO_DIR_OUT,
                 (CSP_OPT_FLAGS)CSP_GPIO_FLAG_MODE_NONE,
                 (CPU_BOOLEAN  )DEF_NO,
                 (CSP_OPT      )DEF_BIT_NONE,
                 (CSP_OPT      )DEF_BIT_NONE);
    
    BSP_LED_Off(0);    
}


/*
*********************************************************************************************************
*                                          BSP_PostInit()
*
* Description : Initialize all the peripherals that required OS services (OS initialized)
*
* Argument(s) : none.
*
* Return(s)   : none.

* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  BSP_PostInit (void)
{
}

/*
*********************************************************************************************************
*                                            BSP_LED_Off()
*
* Description : Turns OFF any or all of the LEDs on the board.
*
* Argument(s) : led    The ID of the LED control:
*                      0    turns OFF ALL the LEDs on the board.
*                      1    turns OFF LED1 on the board.
*                      2    turns OFF LED2 on the board.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  BSP_LED_Off (CPU_INT08U led)
{
    switch (led) {
        case 0u:
             CSP_GPIO_BitClr(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED_GRP);
             break;
             
        case 1u:
             CSP_GPIO_BitClr(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED1);        
             break;

        case 2u:
             CSP_GPIO_BitClr(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED2);         
             break;

        default:
             break;
    }
}


/*
*********************************************************************************************************
*                                             BSP_LED_On()
*
* Description : Turn ON any or all the LEDs on the board.
*
* Argument(s) : led    The ID of the LED control:
*                      0    turns ON ALL the LEDs on the board.
*                      1    turns ON LED1 on the board.
*                      2    turns ON LED2 on the board.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  BSP_LED_On (CPU_INT08U led)
{
    switch (led) {

        case 0u:
             CSP_GPIO_BitSet(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED_GRP);
             break;
             
        case 1u:
             CSP_GPIO_BitSet(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED1);
             break;

        case 2u:
             CSP_GPIO_BitSet(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED2);
             break;
             
        default:
             break;
    }
}


/*
*********************************************************************************************************
*                                             BSP_LED_Toggle()
*
* Description : Toggles any or all the LEDs on the board.
*
* Argument(s) : led    The ID of the LED control:
*                      0    toggle ALL the LEDs on the board.
*                      1    toggles LED1 on the board.
*                      2    toggle LED2 on the board.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  BSP_LED_Toggle (CPU_INT08U led)
{
    CPU_REG32  reg;
    switch (led) {

        case 0u:
             CSP_GPIO_BitToggle(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED_GRP);            
             break;
             
        case 1u:
             CSP_GPIO_BitToggle(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED1);
             break;

        case 2u:
             CSP_GPIO_BitToggle(CSP_GPIO_PORT_NBR_F, BSP_GPIO_PORTF_LED2);        
             break;
             
        default:
             break;
    }
}


/*
*********************************************************************************************************
*                                         BSP_PB_GetStatus()
*
* Description : Get the status of a push button on the board.
*
* Argument(s) : pb      The ID of the push button to probe
*
*                       1    probe the push button PSW1
*                       2    probe the push button PSW2
*
* Return(s)   : DEF_FALSE   if the push button is pressed
*               DEF_TRUE    if the push button is not pressed
*********************************************************************************************************
*/

CPU_BOOLEAN  BSP_PB_GetStatus (CPU_INT08U pb)
{
    CPU_BOOLEAN   status;
        

    status   = DEF_TRUE;
    
    switch (pb) {
        case 1:
            break;

        case 2:
            break;
    
        default:
            break;
    }

    return (status);
}


/*
*********************************************************************************************************
*********************************************************************************************************
**                                                 OS FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                     INTERRUPT CONTROLLER HANDLER
*
* Description: Handles all Cortex M3 NVIC's external sources interrupts
*
* Arguments  : none.
*
* Note(s)    : none.
*********************************************************************************************************
*/

void  OS_CPU_IntHandler (void) 
{
    CPU_SR_ALLOC();
    
    
    CPU_CRITICAL_ENTER();                                       /* Tell the OS that we are starting an ISR              */

    OSIntEnter();

    CPU_CRITICAL_EXIT();
    
    CSP_IntHandler();                                           /* Call the generic CSP interrupt handler.              */
    
    OSIntExit();                                                /* Tell the OS that we are leaving the ISR              */
}

/*
************************************************************************************************************************
*                                                INITIALIZE TICKER INTERRUPT
*
* Description: Initialize the the Tick Interrupt.
*
* Arguments  : none.
*
* Note(s)    : (1) This function MUST be called after OSStart() & after processor initialization.
************************************************************************************************************************
*/

void  OS_CPU_TickInit (CPU_INT32U  tick_rate)
{
    CPU_INT32U  cnts;
    CPU_INT32U  cpu_freq;
    
    cpu_freq = CSP_PM_CPU_ClkFreqGet();
    cnts     = (cpu_freq / tick_rate);                          /* Calculate the number of SysTick counts               */

    OS_CPU_SysTickInit(cnts);                                   /* Call the Generic OS Systick initialization           */
}

