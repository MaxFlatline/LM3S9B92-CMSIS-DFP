;/*
;********************************************************************************************************
;                                    EXCEPTION VECTORS & STARTUP CODE
;
; File      : cstartup.s
; For       : ARMv6M Cortex-M3
; Mode      : Thumb2
; Toolchain : RealView Development Suite
;             RealView Microcontroller Development Kit (MDK)
;             ARM Developer Suite (ADS)
;             Keil uVision
;********************************************************************************************************
;*/

;/*
;********************************************************************************************************
;*                           <<< Use Configuration Wizard in Context Menu >>>
;*
;* Note(s) : (1) The �Vision4 Configuration Wizard enables menu driven configuration of assembler, 
;*               C/C++, or debugger initialization files. The Configuration Wizard uses control items 
;*               that are embedded into the comments of the configuration file.
;*
;********************************************************************************************************
;*/

;/*
;********************************************************************************************************
;*                                              STACK DEFINITIONS
;*
;* Configuration Wizard Menu:
;* // <h> Stack Configuration
;* //   <o> Stack Size (in Bytes) <0x0-0xFFFFFFFF:8>
;* // </h>;
;*********************************************************************************************************
;*/

Stack   EQU     0x00000100

        AREA    STACK, NOINIT, READWRITE, ALIGN=3
StackMem
        SPACE   Stack      ; Allocate space for the stack.
__initial_sp

;/*
;******************************************************************************
;                                           HEAP DEFINITIONS
; <o> Heap Size (in Bytes) <0x0-0xFFFFFFFF:8>
;
;******************************************************************************
Heap    EQU     0x00000000

        AREA    HEAP, NOINIT, READWRITE, ALIGN=3
__heap_base
HeapMem
        SPACE   Heap      ; Allocate space for the heap.
__heap_limit

;******************************************************************************

;
;******************************************************************************
        PRESERVE8   ; Indicate that the code in this file preserves 8-byte alignment of the stack.

;******************************************************************************
;

;
;******************************************************************************
        AREA    RESET, CODE, READONLY           ; Place code into the reset code section.
        THUMB

;******************************************************************************
;
; The vector table.
;
;******************************************************************************
        EXPORT  __Vectors

            IMPORT  BSP_IntHandlerGPIOA
            IMPORT  BSP_IntHandlerGPIOB
            IMPORT  BSP_IntHandlerGPIOC
            IMPORT  BSP_IntHandlerGPIOD
            IMPORT  BSP_IntHandlerGPIOE
            IMPORT  BSP_IntHandlerUART0
            IMPORT  BSP_IntHandlerUART1
            IMPORT  BSP_IntHandlerSSI0
            IMPORT  BSP_IntHandlerI2C0
            IMPORT  BSP_IntHandlerPWMFLT
            IMPORT  BSP_IntHandlerPWMGEN0
            IMPORT  BSP_IntHandlerPWMGEN1
            IMPORT  BSP_IntHandlerPWMGEN2
            IMPORT  BSP_IntHandlerQEI0   
            IMPORT  BSP_IntHandlerADC0
            IMPORT  BSP_IntHandlerADC1
            IMPORT  BSP_IntHandlerADC2
            IMPORT  BSP_IntHandlerADC3
            IMPORT  BSP_IntHandlerWATCHDOG
            IMPORT  BSP_IntHandlerTIMER0A
            IMPORT  BSP_IntHandlerTIMER0B

            IMPORT  BSP_IntHandlerTIMER1A
            IMPORT  BSP_IntHandlerTIMER1B
            IMPORT  BSP_IntHandlerTIMER2A
            IMPORT  BSP_IntHandlerTIMER2B
            IMPORT  BSP_IntHandlerCOMP0
            IMPORT  BSP_IntHandlerCOMP1
            IMPORT  BSP_IntHandlerCOMP2
            IMPORT  BSP_IntHandlerSYSCTL
            IMPORT  BSP_IntHandlerFLASH
            IMPORT  BSP_IntHandlerGPIOF
            IMPORT  BSP_IntHandlerGPIOG
            IMPORT  BSP_IntHandlerGPIOH
            IMPORT  BSP_IntHandlerUART2
            IMPORT  BSP_IntHandlerSSI1
            IMPORT  BSP_IntHandlerTIMER3A
            IMPORT  BSP_IntHandlerTIMER3B

            IMPORT  BSP_IntHandlerI2C1
            IMPORT  BSP_IntHandlerCAN0
            IMPORT  BSP_IntHandlerCAN1
            IMPORT  BSP_IntHandlerETH
            IMPORT  BSP_IntHandlerHIBERNATE
            IMPORT  BSP_IntHandlerUSB
            IMPORT  BSP_IntHandlerUDMA_SW
            IMPORT  BSP_IntHandlerUDMA_ERR
            IMPORT  BSP_IntHandlerADC1_0
            IMPORT  BSP_IntHandlerADC1_1
            IMPORT  BSP_IntHandlerADC1_2
            IMPORT  BSP_IntHandlerADC1_3
    
            IMPORT  BSP_IntHandlerI2S0
            IMPORT  BSP_IntHandlerEPI
            IMPORT  BSP_IntHandlerGPIOJ

            IMPORT  OS_CPU_PendSVHandler
            IMPORT  OS_CPU_SysTickHandler


__Vectors       DCD     __initial_sp                      ; Top of Stack
                DCD     Reset_Handler                     ; Reset Handler
                DCD     App_NMI_ISR                       ; NMI Handler
                DCD     App_Fault_ISR                     ; Hard Fault Handler
                DCD     App_MemFault_ISR                  ; MPU Fault Handler
                DCD     App_BusFault_ISR                  ; Bus Fault Handler
                DCD     App_UsageFault_ISR                ; Usage Fault Handler
                DCD     App_Spurious_ISR                  ; Reserved
                DCD     App_Spurious_ISR                  ; Reserved
                DCD     App_Spurious_ISR                  ; Reserved
                DCD     App_Spurious_ISR                  ; Reserved
                DCD     App_Spurious_ISR                  ; SVCall Handler
                DCD     App_Spurious_ISR                  ; Debug Monitor Handler
                DCD     App_Spurious_ISR                  ; Reserved
                DCD     OS_CPU_PendSVHandler              ; PendSV Handler
                DCD     OS_CPU_SysTickHandler             ; SysTick Handler

                                                          ; External Interrupts
                DCD     BSP_IntHandlerGPIOA               ; 16 
                DCD     BSP_IntHandlerGPIOB                 
                DCD     BSP_IntHandlerGPIOC	       
                DCD     BSP_IntHandlerGPIOD        
                DCD     BSP_IntHandlerGPIOE               ; 20  
                DCD     BSP_IntHandlerUART0        
                DCD     BSP_IntHandlerUART1
                DCD     BSP_IntHandlerSSI0         
                DCD     BSP_IntHandlerI2C0
                DCD     BSP_IntHandlerPWMFLT       
                DCD     BSP_IntHandlerPWMGEN0      
                DCD     BSP_IntHandlerPWMGEN1      
                DCD     BSP_IntHandlerPWMGEN2      
                DCD     BSP_IntHandlerQEI0 
                DCD     BSP_IntHandlerADC0                ; 30
                DCD     BSP_IntHandlerADC1 
                DCD     BSP_IntHandlerADC2 
                DCD     BSP_IntHandlerADC3 
				DCD     BSP_IntHandlerWATCHDOG
                DCD     BSP_IntHandlerTIMER0A  
                DCD     BSP_IntHandlerTIMER0B  
                DCD     BSP_IntHandlerTIMER1A  
                DCD     BSP_IntHandlerTIMER1B  
                DCD     BSP_IntHandlerTIMER2A  
                DCD     BSP_IntHandlerTIMER2B  
                DCD     BSP_IntHandlerCOMP0    
                DCD     BSP_IntHandlerCOMP1    
                DCD     BSP_IntHandlerCOMP2  	
                DCD     BSP_IntHandlerSYSCTL    
				DCD     BSP_IntHandlerFLASH
                DCD     BSP_IntHandlerGPIOF     
				DCD     BSP_IntHandlerGPIOG
                DCD     BSP_IntHandlerGPIOH
                DCD     BSP_IntHandlerUART2
                DCD     BSP_IntHandlerSSI1
                DCD     BSP_IntHandlerTIMER3A
                DCD     BSP_IntHandlerTIMER3B
                DCD     BSP_IntHandlerI2C1
                DCD     BSP_IntHandlerCAN0
                DCD     BSP_IntHandlerCAN1
                DCD     App_Reserved_ISR
                DCD     BSP_IntHandlerETH
                DCD     App_Reserved_ISR                
                DCD     BSP_IntHandlerUSB
                DCD     BSP_IntHandlerUDMA_SW
                DCD     BSP_IntHandlerUDMA_ERR
                DCD     BSP_IntHandlerADC1_0
                DCD     BSP_IntHandlerADC1_1
                DCD     BSP_IntHandlerADC1_2
                DCD     BSP_IntHandlerADC1_3
                DCD     BSP_IntHandlerI2S0
                DCD     BSP_IntHandlerEPI
                DCD     BSP_IntHandlerGPIOJ
                
;                AREA    |.text|, CODE, READONLY




;******************************************************************************
;
; This is the code that gets called when the processor first starts execution
; following a reset event.
;
;******************************************************************************
        EXPORT  Reset_Handler
Reset_Handler
        ;
        ; Call the C library enty point that handles startup.  This will copy
        ; the .data section initializers from flash to SRAM and zero fill the
        ; .bss section.
        ;
        IMPORT  __main

        IF      {CPU} = "Cortex-M4.fp"
        LDR     R0, =0xE000ED88           ; Enable CP10,CP11
        LDR     R1,[R0]
        ORR     R1,R1,#(0xF << 20)
        STR     R1,[R0]
        ENDIF

        B       __main

;******************************************************************************
;
; This is the code that gets called when the processor receives a NMI.  This
; simply enters an infinite loop, preserving the system state for examination
; by a debugger.
;
;******************************************************************************
;NmiSR
;        B       NmiSR
App_NMI_ISR     PROC
                EXPORT  App_NMI_ISR               [WEAK]
                B       .
                ENDP
;******************************************************************************
;
; This is the code that gets called when the processor receives a fault
; interrupt.  This simply enters an infinite loop, preserving the system state
; for examination by a debugger.
;
;******************************************************************************
;FaultISR
;        B       FaultISR
App_Fault_ISR\
                PROC
                EXPORT  App_Fault_ISR             [WEAK]
                B       .
                ENDP


App_MemFault_ISR\
                PROC
                EXPORT  App_MemFault_ISR          [WEAK]
                B       .
                ENDP


App_BusFault_ISR\
                PROC
                EXPORT  App_BusFault_ISR          [WEAK]
                B       .
                ENDP


App_UsageFault_ISR\
                PROC
                EXPORT  App_UsageFault_ISR        [WEAK]
                B       .
                ENDP
App_Spurious_ISR\
                PROC
                EXPORT  App_Spurious_ISR          [WEAK]
                B       .
                ENDP
App_Reserved_ISR\
                PROC
                EXPORT  App_Reserved_ISR          [WEAK]
                B       .
                ENDP


;******************************************************************************
;
; This is the code that gets called when the processor receives an unexpected
; interrupt.  This simply enters an infinite loop, preserving the system state
; for examination by a debugger.
;
;******************************************************************************
;IntDefaultHandler
;        B       IntDefaultHandler

;******************************************************************************
;
; Make sure the end of this section is aligned.
;
;******************************************************************************
        ALIGN

;******************************************************************************
;
; Some code in the normal code section for initializing the heap and stack.
;
;******************************************************************************
        AREA    |.text|, CODE, READONLY

;******************************************************************************
;
; The function expected of the C library startup code for defining the stack
; and heap memory locations.  For the C library version of the startup code,
; provide this function so that the C library initialization code can find out
; the location of the stack and heap.
;
;******************************************************************************
    IF :DEF: __MICROLIB
        EXPORT  __initial_sp
        EXPORT  __heap_base
        EXPORT __heap_limit
    ELSE
        IMPORT  __use_two_region_memory
        EXPORT  __user_initial_stackheap
__user_initial_stackheap
        LDR     R0, =HeapMem
        LDR     R1, =(StackMem + Stack)
        LDR     R2, =(HeapMem + Heap)
        LDR     R3, =StackMem
        BX      LR
    ENDIF

;******************************************************************************
;
; Make sure the end of this section is aligned.
;
;******************************************************************************
        ALIGN

;******************************************************************************
;
; Tell the assembler that we're done.
;
;******************************************************************************
        END
